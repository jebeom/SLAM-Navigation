
"use strict";

let Axis = require('./Axis.js');
let MotorsStatus = require('./MotorsStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let named_input_output = require('./named_input_output.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let PantiltStatus = require('./PantiltStatus.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let ptz = require('./ptz.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Register = require('./Register.js');
let StringStamped = require('./StringStamped.js');
let PresenceSensor = require('./PresenceSensor.js');
let Interfaces = require('./Interfaces.js');
let encoders = require('./encoders.js');
let Alarms = require('./Alarms.js');
let SubState = require('./SubState.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let WatchdogStatusArray = require('./WatchdogStatusArray.js');
let ArmStatus = require('./ArmStatus.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let WatchdogStatus = require('./WatchdogStatus.js');
let Pose2DArray = require('./Pose2DArray.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let Registers = require('./Registers.js');
let MotorReferenceValueArray = require('./MotorReferenceValueArray.js');
let InverterStatus = require('./InverterStatus.js');
let Data = require('./Data.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let Logger = require('./Logger.js');
let StringArray = require('./StringArray.js');
let OdomCalibrationStatus = require('./OdomCalibrationStatus.js');
let LaserStatus = require('./LaserStatus.js');
let State = require('./State.js');
let MotorPID = require('./MotorPID.js');
let RecordStatus = require('./RecordStatus.js');
let OdomManualCalibrationStatus = require('./OdomManualCalibrationStatus.js');
let LaserMode = require('./LaserMode.js');
let ReturnMessage = require('./ReturnMessage.js');
let BoolArray = require('./BoolArray.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let MotorStatus = require('./MotorStatus.js');
let QueryAlarm = require('./QueryAlarm.js');
let PantiltStatusStamped = require('./PantiltStatusStamped.js');
let BatteryStatus = require('./BatteryStatus.js');
let alarmmonitor = require('./alarmmonitor.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let inputs_outputs = require('./inputs_outputs.js');
let OdomCalibrationStatusStamped = require('./OdomCalibrationStatusStamped.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let OdomManualCalibrationStatusStamped = require('./OdomManualCalibrationStatusStamped.js');
let MotorReferenceValue = require('./MotorReferenceValue.js');
let MotorCurrent = require('./MotorCurrent.js');
let ElevatorAction = require('./ElevatorAction.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorResult = require('./SetElevatorResult.js');

module.exports = {
  Axis: Axis,
  MotorsStatus: MotorsStatus,
  AlarmSensor: AlarmSensor,
  named_input_output: named_input_output,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  PantiltStatus: PantiltStatus,
  BatteryStatusStamped: BatteryStatusStamped,
  ptz: ptz,
  ElevatorStatus: ElevatorStatus,
  Register: Register,
  StringStamped: StringStamped,
  PresenceSensor: PresenceSensor,
  Interfaces: Interfaces,
  encoders: encoders,
  Alarms: Alarms,
  SubState: SubState,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  WatchdogStatusArray: WatchdogStatusArray,
  ArmStatus: ArmStatus,
  BatteryDockingStatus: BatteryDockingStatus,
  PresenceSensorArray: PresenceSensorArray,
  named_inputs_outputs: named_inputs_outputs,
  MotorHeadingOffset: MotorHeadingOffset,
  WatchdogStatus: WatchdogStatus,
  Pose2DArray: Pose2DArray,
  alarmsmonitor: alarmsmonitor,
  Registers: Registers,
  MotorReferenceValueArray: MotorReferenceValueArray,
  InverterStatus: InverterStatus,
  Data: Data,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  Logger: Logger,
  StringArray: StringArray,
  OdomCalibrationStatus: OdomCalibrationStatus,
  LaserStatus: LaserStatus,
  State: State,
  MotorPID: MotorPID,
  RecordStatus: RecordStatus,
  OdomManualCalibrationStatus: OdomManualCalibrationStatus,
  LaserMode: LaserMode,
  ReturnMessage: ReturnMessage,
  BoolArray: BoolArray,
  Pose2DStamped: Pose2DStamped,
  MotorStatus: MotorStatus,
  QueryAlarm: QueryAlarm,
  PantiltStatusStamped: PantiltStatusStamped,
  BatteryStatus: BatteryStatus,
  alarmmonitor: alarmmonitor,
  MotorsStatusDifferential: MotorsStatusDifferential,
  inputs_outputs: inputs_outputs,
  OdomCalibrationStatusStamped: OdomCalibrationStatusStamped,
  SafetyModuleStatus: SafetyModuleStatus,
  OdomManualCalibrationStatusStamped: OdomManualCalibrationStatusStamped,
  MotorReferenceValue: MotorReferenceValue,
  MotorCurrent: MotorCurrent,
  ElevatorAction: ElevatorAction,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorAction: SetElevatorAction,
  SetElevatorResult: SetElevatorResult,
};
