// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let StatusResponse = require('../msg/StatusResponse.js');

//-----------------------------------------------------------

class StartAssetsWriterRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pose_graph_filename = null;
      this.bag_filenames = null;
    }
    else {
      if (initObj.hasOwnProperty('pose_graph_filename')) {
        this.pose_graph_filename = initObj.pose_graph_filename
      }
      else {
        this.pose_graph_filename = '';
      }
      if (initObj.hasOwnProperty('bag_filenames')) {
        this.bag_filenames = initObj.bag_filenames
      }
      else {
        this.bag_filenames = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StartAssetsWriterRequest
    // Serialize message field [pose_graph_filename]
    bufferOffset = _serializer.string(obj.pose_graph_filename, buffer, bufferOffset);
    // Serialize message field [bag_filenames]
    bufferOffset = _serializer.string(obj.bag_filenames, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StartAssetsWriterRequest
    let len;
    let data = new StartAssetsWriterRequest(null);
    // Deserialize message field [pose_graph_filename]
    data.pose_graph_filename = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [bag_filenames]
    data.bag_filenames = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.pose_graph_filename);
    length += _getByteLength(object.bag_filenames);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/StartAssetsWriterRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1b1c67f00671ade438d42425ed7f959a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    string pose_graph_filename
    string bag_filenames
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StartAssetsWriterRequest(null);
    if (msg.pose_graph_filename !== undefined) {
      resolved.pose_graph_filename = msg.pose_graph_filename;
    }
    else {
      resolved.pose_graph_filename = ''
    }

    if (msg.bag_filenames !== undefined) {
      resolved.bag_filenames = msg.bag_filenames;
    }
    else {
      resolved.bag_filenames = ''
    }

    return resolved;
    }
};

class StartAssetsWriterResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = new StatusResponse();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StartAssetsWriterResponse
    // Serialize message field [status]
    bufferOffset = StatusResponse.serialize(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StartAssetsWriterResponse
    let len;
    let data = new StartAssetsWriterResponse(null);
    // Deserialize message field [status]
    data.status = StatusResponse.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += StatusResponse.getMessageSize(object.status);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/StartAssetsWriterResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4e6ca4e44081fa06b258fa12804ea7cb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cartographer_ros_msgs/StatusResponse status
    
    
    ================================================================================
    MSG: cartographer_ros_msgs/StatusResponse
    # Copyright 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    # A common message type to indicate the outcome of a service call.
    uint8 code
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StartAssetsWriterResponse(null);
    if (msg.status !== undefined) {
      resolved.status = StatusResponse.Resolve(msg.status)
    }
    else {
      resolved.status = new StatusResponse()
    }

    return resolved;
    }
};

module.exports = {
  Request: StartAssetsWriterRequest,
  Response: StartAssetsWriterResponse,
  md5sum() { return '05887ee2ac2b77274f43ea95e7d73eaa'; },
  datatype() { return 'cartographer_ros_msgs/StartAssetsWriter'; }
};
