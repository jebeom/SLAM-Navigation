
"use strict";

let MockPetition = require('./MockPetition.js')
let WaitPetition = require('./WaitPetition.js')

module.exports = {
  MockPetition: MockPetition,
  WaitPetition: WaitPetition,
};
