
"use strict";

let Mock = require('./Mock.js');
let Wait = require('./Wait.js');

module.exports = {
  Mock: Mock,
  Wait: Wait,
};
