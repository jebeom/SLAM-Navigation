#ifndef __PROCEDURE_COMPONENT_GOTO_RMBF_H
#define __PROCEDURE_COMPONENT_GOTO_RMBF_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <actionlib/client/simple_action_client.h>
#include <robotnik_navigation_msgs/RobotnikMoveBaseFlexAction.h>

#include <dynamic_reconfigure/DoubleParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/Config.h>

#include <tf/transform_listener.h>

#include <boost/algorithm/string.hpp>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/GoTo.h>
#include <robot_local_control_msgs/GoToPetition.h>
#include <robot_local_control_msgs/Status.h>

#include <boost/scoped_ptr.hpp>

#include <robot_local_control_procedures/goto_procedure.h>
#include <robot_local_control_msgs/SetGoToPetition.h>
#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>

#include <mbf_msgs/ExePathAction.h>
#include <mbf_msgs/GetPathAction.h>
#include <mbf_msgs/RecoveryAction.h>
#include <mbf_msgs/MoveBaseAction.h>

// TODO: finally we have to components implementing the same procedure, so we cannot
// define the struct GoToProcedure twice. We can:
// - we include it on the msg creation (will involve modifying some ros library)
// - have a common header for them in each package.
// struct GoToProcedure
//{
//  robot_local_control_msgs::GoTo procedure;
//  procedures_msgs::ProcedureHeader header;
//  procedures_msgs::ProcedureState state;
//
//  typedef robot_local_control_msgs::GoTo Type;
//  typedef robot_local_control_msgs::GoToPetition Petition;
//};

namespace procedures
{
class ProcedureComponentGoToRMBF : public ProcedureComponent<GoToProcedure>
{
public:
  ProcedureComponentGoToRMBF();
  ProcedureComponentGoToRMBF(ros::NodeHandle h, std::string name = "GoToRMBFComponent");

  virtual void rosReadParams();

  bool setActionNamespace(std::string action_namespace);

  bool setGlobalFrame(std::string global_frame);

  bool setBaseFrame(std::string base_frame);

  std::string getActionNamespace();
  std::string getGlobalFrame();
  std::string getBaseFrame();

  virtual bool addProcedure(const GoToProcedure::Petition::Request& request,
                            GoToProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response);

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  bool isGoalReached(const robot_local_control_msgs::Pose2DStamped& goal);

  bool setGoToActionClient(robot_local_control_msgs::SetGoToPetition::Request& request,
                           robot_local_control_msgs::SetGoToPetition::Response& response);

  enum Steps
  {
    Init = 0,
    SetDefaultLaserMode = 1,
    GetNextGoal = 2,
    GetPlan = 3,
    ExecPlan = 4,
    WaitForResult = 5,
    Recovery = 6,
    RecoveryCleanCostmap = 7,
    RecoverySetLaserMode = 8,
    WaitAfterRecovery = 9,
  };

protected:
  virtual int rosSetup();

  virtual int setup();

  virtual void initState();

  virtual void standbyState();

  virtual void readyState();

  virtual std::string stepToString(int step);

  void robotStatusCallback(const robot_local_control_msgs::Status& status);

  // Called every time feedback is received for the goal
  void exePathFeedbackCb(const mbf_msgs::ExePathActionFeedback& feedback);

  ///////////////////// Step Methods
  void setDefaultLaserModeStep();
  void getNextGoalsStep();
  void getPlanStep();
  void execPlanStep();
  void waitForResultStep();
  void recoveryStep();
  void recoveryCleanCostmapStep();
  void recoverySetLaserModeStep();
  void waitAfterRecoveryStep();

  bool setLaserMode(std::string);

protected:
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::RobotnikMoveBaseFlexAction>> action_client_;
  std::string action_namespace_;

  // Action clients
  std::string robotnik_move_base_flex_namespace_;
  //! Action client RMBF ExePathAction
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::RobotnikMoveBaseFlexAction>> exe_goal_action_client_;
  //! Action client MBF RecoveryAction
  boost::scoped_ptr<actionlib::SimpleActionClient<mbf_msgs::RecoveryAction>> recovery_action_client_;


  ros::ServiceServer set_goto_ac_server_;

  ros::ServiceClient clear_costmaps_client_;
  //ros::ServiceClient set_goal_tolerance_client_;
  ros::ServiceClient laser_mode_client_;
  std::string global_frame_;
  std::string base_frame_;

  ros::Subscriber robot_status_sub_, mbf_feedback_sub_;
  robot_local_control_msgs::Status robot_status_;

  tf::TransformListener tf_listener_;
  int index_of_current_goal_;
  robotnik_navigation_msgs::RobotnikMoveBaseFlexGoal current_goal_;
  double default_yaw_tolerance_;
  double default_xy_tolerance_;
  bool clear_costmaps_before_send_goal_;
  bool has_laser_security_;

  mbf_msgs::GetPathResultConstPtr current_plan_;
  mbf_msgs::ExePathFeedback exe_path_feedback_;
  int exe_path_errors_;      // errors executing the path
  int max_exe_path_errors_;  // max number of errors allowed
  // If the goal is obstructed, how many meters the planner can relax the constraint in x and y before failing
  double global_plan_tolerance_;
  // How many times to allow for planning retries before executing the recovery_behaviors
  int max_planning_retries_;
  int current_planning_retries_;

  //! conservative recovery behaviour
  std::string recovery_behavior_conservative_;
  //! aggresive recovery behaviour
  std::string recovery_behavior_aggresive_;
  //! Max number of times we will try to recover from any error
  int max_recovery_retries_;
  //! The current number of retries
  int current_recovery_retries_;
  //! Recovery behaviour to apply
  int current_recovery_behaviour_;
  //! Waiting time before start the recovery
  double recovery_waiting_time_;
  //! Time to wait when the safety stop is detecting before trying to recover
  double safety_stop_recovery_waiting_time_;
  //! laser mode to recover from safety collision
  std::string safety_laser_recovery_mode_;
  //! laser mode used for standard navigation
  std::string safety_laser_std_mode_;
  //! Saves the time when the safety was triggered
  ros::Time t_safety_triggered_;
  //! Goal target type. The type of navigation can be CARTESIAN or GPS
  std::string goal_target_type_;
  //! Navigation type. The type of navigation can be POINT_TO_POINT or END_POINT
  std::string navigation_type_;
  //! Controller
  std::string controller_;
  //! Planner. The planner can be none
  std::string planner_;
  

  bool current_safety_stop_;
  bool on_safety_stop_recovery_;

  bool cancel_request;
};
}  // namespace procedures
#endif  // __PROCEDURE_COMPONENT_GOTO_RMBF_H