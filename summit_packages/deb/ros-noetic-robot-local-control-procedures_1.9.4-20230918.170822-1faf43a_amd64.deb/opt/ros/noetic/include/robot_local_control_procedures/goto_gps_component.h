#ifndef __PROCEDURE_COMPONENT_GOTO_GPS_H
#define __PROCEDURE_COMPONENT_GOTO_GPS_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <actionlib/client/simple_action_client.h>
#include <robotnik_navigation_msgs/RobotnikMoveBaseFlexAction.h>

#include <dynamic_reconfigure/DoubleParameter.h>
#include <dynamic_reconfigure/Reconfigure.h>
#include <dynamic_reconfigure/Config.h>

#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/GoToGPS.h>
#include <robot_local_control_msgs/GoToGPSPetition.h>

#include <boost/scoped_ptr.hpp>

#include <robot_local_control_msgs/SetGoToPetition.h>
#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>

// TODO: finally we have to components implementing the same procedure, so we cannot
// define the struct GoToGPSProcedure twice. We can:
// - we include it on the msg creation (will involve modifying some ros library)
// - have a common header for them in each package.
// struct GoToGPSProcedure
//{
//  robot_local_control_msgs::GoTo procedure;
//  procedures_msgs::ProcedureHeader header;
//  procedures_msgs::ProcedureState state;
//
//  typedef robot_local_control_msgs::GoTo Type;
//  typedef robot_local_control_msgs::GoToPetition Petition;
//};

#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>

#include <robot_local_control_msgs/GoToGPS.h>
#include <robot_local_control_msgs/GoToGPSPetition.h>


#include <sensor_msgs/NavSatFix.h>

struct GoToGPSProcedure
{
  robot_local_control_msgs::GoToGPS procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::GoToGPS Type;
  typedef robot_local_control_msgs::GoToGPSPetition Petition;
};


namespace procedures
{
class ProcedureComponentGoToGPS : public ProcedureComponent<GoToGPSProcedure>
{
public:
  ProcedureComponentGoToGPS();
  ProcedureComponentGoToGPS(ros::NodeHandle h, std::string name = "GoToGPSComponent");

  virtual void rosReadParams();

  bool setActionNamespace(std::string action_namespace);

  bool setGlobalFrame(std::string global_frame);

  bool setBaseFrame(std::string base_frame);

  std::string getActionNamespace();
  std::string getGlobalFrame();
  std::string getBaseFrame();

  virtual bool addProcedure(const GoToGPSProcedure::Petition::Request& request,
                            GoToGPSProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response);

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  bool isGoalReached(const robot_local_control_msgs::Pose2DStamped& goal);

  bool setGoToGPSActionClient(robot_local_control_msgs::SetGoToPetition::Request& request,
                              robot_local_control_msgs::SetGoToPetition::Response& response);

protected:
  virtual int rosSetup();

  virtual int setup();

  virtual void initState();

  virtual void standbyState();

  virtual void readyState();

protected:
  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::RobotnikMoveBaseFlexAction> >
      action_client_;
  std::string action_namespace_;
  std::string local_planner_namespace_;
  std::string global_planner_namespace_;
  std::string set_max_velocity_param_name_;

  ros::ServiceServer set_goto_ac_server_;

  ros::ServiceClient clear_costmaps_client_;
  ros::ServiceClient set_local_planner_params_client_;
  ros::ServiceClient laser_mode_client_;
  std::string global_frame_;
  std::string base_frame_;
  std::string first_point_planner;
  std::string planner_;
  std::string controller_;
  std::string type_navigation_;

  ros::Subscriber gps_sub_;
  std::string gps_sub_name_;
  sensor_msgs::NavSatFix current_gps_;
  void gpsFixCB(const sensor_msgs::NavSatFix &msg);

  tf::TransformListener tf_listener_;
  bool lookupTransform(const std::string& source, const std::string& target, const ros::Time& time, tf::StampedTransform& transform);
  bool has_safety_laser_;
  int current_step_;
  double max_velocity_minimum_value_;
  double max_velocity_maximum_value_;
};
}  // namespace procedures
#endif  // __SUMMIT_AIRBUS_EBH_URW_PROCEDURE_COMPONENT_GOTO_MOVEBASE_H
