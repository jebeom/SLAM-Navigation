#ifndef _GOTO_PROCEDURE_
#define _GOTO_PROCEDURE_

#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>

#include <robot_local_control_msgs/GoTo.h>
#include <robot_local_control_msgs/GoToPetition.h>

struct GoToProcedure
{
  robot_local_control_msgs::GoTo procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::GoTo Type;
  typedef robot_local_control_msgs::GoToPetition Petition;
};

#endif  // _GOTO_PROCEDURE_
