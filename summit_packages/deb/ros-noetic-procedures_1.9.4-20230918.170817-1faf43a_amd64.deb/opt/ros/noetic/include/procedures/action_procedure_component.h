#ifndef __PROCEDURE_COMPONENT_ACTION_H
#define __PROCEDURE_COMPONENT_ACTION_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <tf/transform_listener.h>

#include <robot_local_control_msgs/Pose2DStamped.h>
#include <robot_local_control_msgs/Twist2D.h>
#include <robot_local_control_msgs/GoTo.h>
#include <robot_local_control_msgs/GoToPetition.h>

#include <boost/scoped_ptr.hpp>

namespace procedures
{
template <class TProcedure, class TAction>
class ActionProcedureComponent : public ProcedureComponent<TProcedure>
{
public:
  ActionProcedureComponent() : ProcedureComponent<TProcedure>()
  {
  }
  
  ActionProcedureComponent(ros::NodeHandle h, std::string name = "ActionComponent")
    : ProcedureComponent<TProcedure>(h, name)
  {
    // XXX: we need to fully qualify members in the parent class, due to the compiler. Remember adding this-> to all
    // access them, otherwise compiler will fail

    this->component_name = name;

    this->rosReadParams();
  }

  virtual void rosReadParams()
  {
    // std::string action_namespace_from_param = "";

    // // XXX: this way of reading parameters does not work, compiler complains, so use non templated version
    // // ProcedureComponent<TProcedure>::pnh_.param<std::string>("action_namespace", action_namespace_from_param,
    // //                                                            action_namespace_from_param);
    // ProcedureComponent<TProcedure>::pnh_.getParam("action_namespace", action_namespace_from_param);
    // this->setActionNamespace(action_namespace_from_param);

    bool required = true;
    action_namespace_ = "";
    rcomponent::RComponent::readParam(ProcedureComponent<TProcedure>::pnh_, "action_namespace", action_namespace_,
                                      action_namespace_, required);

    ProcedureComponent<TProcedure>::rosReadParams();
  }

  bool setActionNamespace(std::string action_namespace)
  {
    this->action_namespace_ = action_namespace;
    if (action_namespace == "")
    {
      RCOMPONENT_ERROR_STREAM("action_namespace param is empty. I cannot work without it!");
      return false;
    }
    return true;
  }

  std::string getActionNamespace()
  {
    return action_namespace_;
  }

  virtual bool addProcedure(const typename TProcedure::Petition::Request& request,
                            typename TProcedure::Petition::Response& response)
  {
    // action client related checks: to move to an ActionProcedure class
    if (isActionClientAvailable() == false)
    {
      // TODO:: add error management
      std::string error_message = "Cannot add procedure because ActionClient is not running";
      RCOMPONENT_ERROR_STREAM(error_message);
      response.result.result = procedures_msgs::ProcedureResult::ERROR;
      response.result.message = error_message;
      return true;
    }

    typename TAction::_action_goal_type::_goal_type goal;
    convertProcedureToAction(request.procedure, goal);
    this->current_action_goals_.push_back(goal);

    return ProcedureComponent<TProcedure>::addProcedure(request, response);
  }

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response)
  {
    if (action_client_ == NULL or action_client_->isServerConnected() == false)
    {
      // TODO:: add error management
      std::string error_message = "Cannot add procedure because ActionClient is not running";
      RCOMPONENT_ERROR_STREAM(error_message);
      response.result.result = procedures_msgs::ProcedureResult::ERROR;
      response.result.message = error_message;
      return true;
    }

    // Cancel ongoing goals
    action_client_->cancelAllGoals();

    this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
    this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::CANCEL;

    response.state = this->current_procedure_.state;
    response.state.header = this->current_procedure_.header;
    response.result.result = procedures_msgs::ProcedureResult::OK;
    return true;
  }

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response)
  {
    return false;
  }

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response)
  {
    return false;
  }

protected:
  virtual int rosSetup()
  {
    if (this->ros_initialized)
    {
      RCOMPONENT_INFO("Already initialized");
      return rcomponent::INITIALIZED;
    }

    if (action_namespace_ == "")
    {
      RCOMPONENT_ERROR_STREAM("Action namespace is empty. I cannot make the setup!");
      return rcomponent::ReturnValue::ERROR;
    }
    bool spin_action_thread = true;
    action_client_.reset(new actionlib::SimpleActionClient<TAction>(action_namespace_, spin_action_thread));
    return ProcedureComponent<TProcedure>::rosSetup();
  }

  virtual int setup()
  {
    // Checks if has been initialized
    if (this->initialized)
    {
      RCOMPONENT_INFO_STREAM("Already initialized");

      return rcomponent::ReturnValue::INITIALIZED;
    }

    ros::Duration timeout = ros::Duration(5);
    action_client_->waitForServer(timeout);

    if (action_client_->isServerConnected() == false)
    {
      RCOMPONENT_ERROR_STREAM("Cannot connect to Action client: " << action_namespace_);
      return rcomponent::ReturnValue::NOT_INITIALIZED;
    }

    RCOMPONENT_INFO_STREAM("Connected to the Action client: " << action_namespace_);

    this->initialized = true;

    return ProcedureComponent<TProcedure>::setup();
  }

  virtual void initState()
  {
    // If component setup is successful goes to STANDBY (or READY) state
    if (setup() != rcomponent::ERROR)
    {
      this->switchToState(robotnik_msgs::State::STANDBY_STATE);
    }
  }

  virtual void standbyState()
  {
    this->switchToState(robotnik_msgs::State::READY_STATE);
  }

  virtual void readyState()
  {
    // action client related checks: to move to an ActionProcedure class
    if (isActionClientAvailable() == false)
    {
      RCOMPONENT_ERROR_STREAM("Cannot connect to action server: " << action_namespace_);
      this->initialized = false;
      this->switchToState(robotnik_msgs::State::INIT_STATE);
      return;
    }

    if (this->current_procedure_.state.current_state == procedures_msgs::ProcedureState::FINISHED or
        this->current_procedure_.state.current_state == procedures_msgs::ProcedureState::UNKNOWN)
    {
      return;
    }

    // accept pending goal
    if (this->current_procedure_.state.current_state == procedures_msgs::ProcedureState::QUEUED)
    {
      this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::RUNNING;
      this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::START;

      // TODO: add management error
      action_client_->sendGoal(current_action_goals_.front());
      return;
    }

    actionlib::SimpleClientGoalState action_state = action_client_->getState();
    if (action_state.isDone() == true)  // and action_state != actionlib::SimpleClientGoalState::LOST)
    {
      if (action_state == actionlib::SimpleClientGoalState::SUCCEEDED)
      {
        current_action_goals_.erase(current_action_goals_.begin());
        if (current_action_goals_.size() == 0)
        {
          this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
          this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::FINISH;
        }
        /*else
        { // DA problemas a veces
		  RCOMPONENT_WARN_STREAM("Sending goal 2: ");
          action_client_->sendGoal(current_action_goals_.front());
        }*/
      }
      else if (action_state == actionlib::SimpleClientGoalState::LOST)
      {
        this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
        this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::UNKNOWN;
      }
      else if (action_state == actionlib::SimpleClientGoalState::ABORTED)
      {
        this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
        this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::ABORT;
      }
      else
      {
        if (this->current_procedure_.state.current_state != procedures_msgs::ProcedureState::PAUSED)
        {
          this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
          this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::UNKNOWN;
        }
      }
      // else  // can be RECALLED/REJECTED/PREEMPTED/ABORTED
      //{
      //  this->current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
      //  this->current_procedure_.state.last_event = procedures_msgs::ProcedureState::ABORT;
      //}
    }
  }

  virtual bool isActionClientAvailable()
  {
    if (action_client_ == NULL or action_client_->isServerConnected() == false)
    {
      return false;
    }
    return true;
  }

  virtual bool sendGoal(typename TAction::_action_goal_type::_goal_type goal)
  {
    if (isActionClientAvailable() == false)
      return false;

    action_client_->sendGoal(goal);
  }

  virtual actionlib::SimpleClientGoalState getGoalState()
  {
    if (isActionClientAvailable() == false)
      return actionlib::SimpleClientGoalState(actionlib::SimpleClientGoalState::LOST);  // XXX: check this return value

    return action_client_->getState();
  }

  virtual bool convertProcedureToAction(const typename TProcedure::Type& procedure,
                                        typename TAction::_action_goal_type::_goal_type& goal) = 0;

  // virtual bool convertProcedureToActionGoalArray(
  // const TProcedure& procedure, std::vector<typename TAction::_action_goal_type::_goal_type>& goals) = 0;

protected:
  boost::scoped_ptr<actionlib::SimpleActionClient<TAction> > action_client_;
  std::string action_namespace_;
  std::vector<typename TAction::_action_goal_type::_goal_type> current_action_goals_;
};
}
#endif  // __PROCEDURE_COMPONENT_ACTION_H
