#ifndef __PROCEDURE_COMPONENT_H
#define __PROCEDURE_COMPONENT_H

#include <ros/ros.h>

#include <boost/scoped_ptr.hpp>

#include <rcomponent/rcomponent.h>

#include <service_shifter/ShifterServiceServer.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>

#define LOG_PROCEDURE_STREAM                                                                                           \
  "id: " << current_procedure_.header.id << ", state: \"" << current_procedure_.state.current_state                    \
         << "\", last_event: \"" << current_procedure_.state.last_event << "\"" << std::endl

namespace procedures
{
namespace ProcedureComponentConstants
{  // TODO: add this to a ProcedureComponent namespace
const std::string ADD = "add";
const std::string QUERY_STATE = "query_state";
const std::string PAUSE = "pause";
const std::string RESUME = "resume";
const std::string CANCEL = "cancel";
}

class GenericProcedureComponent : public rcomponent::RComponent
{
public:
  // type definitions

  typedef boost::shared_ptr<GenericProcedureComponent> Ptr;

public:
  // TODO: for loading procedurecomponents with pluginlib, we need a constructor without arguments
  // procedurecomponents have this by specifying default values for constructor parameters
  // however, this default values probably are not the good ones in all cases
  // that means that after construction, an init function with the proper values has to be called
  // which results in several calls to some functions, that can trigger spureous warning and error messages

  GenericProcedureComponent() : rcomponent::RComponent(), preemptable_(false)
  {
  }

  GenericProcedureComponent(ros::NodeHandle h, std::string name = "ProcedureComponent")
    : rcomponent::RComponent(h, name)  //, preemptable_(false)
  {
  }

public:
  virtual bool waitUntilComponentIsReady(ros::Duration max_wait_time = ros::Duration(5))
  {
    // TODO: add test for this
    ros::WallRate rate(10);

    ros::Time wait(ros::Time::now() + max_wait_time);
    while (ros::Time::now() < wait)
    {
      if (this->getState() == robotnik_msgs::State::READY_STATE)
        return true;

      rate.sleep();
      ros::spinOnce();
    }
    return false;
  }

  virtual bool addProcedureShifter(const service_shifter::ServiceShifter& request,
                                   service_shifter::ServiceShifter& response) = 0;

  virtual bool queryState(procedures_msgs::ProcedureQuery::Request& request,
                          procedures_msgs::ProcedureQuery::Response& response) = 0;

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response) = 0;

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response) = 0;

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response) = 0;

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response) = 0;

  virtual void convertResponseToServiceShifter(const procedures_msgs::ProcedureState& state,
                                               const procedures_msgs::ProcedureResult& result,
                                               service_shifter::ServiceShifter& shifter) = 0;

  virtual bool isRunningProcedure() = 0;

  virtual bool hasPendingProcedures() = 0;

  virtual bool cancelAllProcedures() = 0;

  bool isPreemptable()
  {
    return preemptable_;
  }

  void setAddProcedureCallbackManager(
      boost::function<bool(const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>&)>
          callback)
  {
    add_procedure_callback_manager_ = callback;
  }

  boost::function<bool(const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>&)>
      add_procedure_callback_manager_;

  virtual void rosReadParams()
  {
    RComponent::rosReadParams();

    bool required = false;
    preemptable_ = false;
    readParam(pnh_, "preemptable", preemptable_, preemptable_, required);
  }

private:
  bool preemptable_;
};

template <class T>
class ProcedureComponent : public GenericProcedureComponent  // rcomponent::RComponent
{
public:
  ProcedureComponent() : GenericProcedureComponent()
  {
    current_procedure_.state.current_state =
        procedures_msgs::ProcedureState::FINISHED;  // at the beginning, we dont have a procedure
    current_step_ = previous_step_ = -1;
    t_step_transition_ = ros::Time(0);
  }

  ProcedureComponent(ros::NodeHandle h, std::string name = "ProcedureComponent") : GenericProcedureComponent(h, name)
  {
    component_name = name;
    current_procedure_.state.current_state =
        procedures_msgs::ProcedureState::FINISHED;  // at the beginning, we dont have a procedure
    current_step_ = previous_step_ = -1;
    t_step_transition_ = ros::Time(0);
  }

protected:
  virtual void rosReadParams()
  {
    GenericProcedureComponent::rosReadParams();
  }

  virtual int rosSetup()
  {
    if (ros_initialized)
    {
      RCOMPONENT_INFO_STREAM("Already initialized");
      return rcomponent::INITIALIZED;
    }

    // XXX: this doesn't work right now, I don't know why, it fails due to the ros message serialization. Should be
    // checked.
    // services_.push_back(
    //    pnh_.advertiseService(ProcedureComponentConstants::ADD, &ProcedureComponent::addProcedure, this));
    //
    //    if (services_.back() == 0)
    //    {
    //      // error!
    //    }

    // this looks for the parameter in the parameters tree
    std::string advertise_services_param_name;
    bool advertise_services_param_name_exists = false;
    advertise_services_param_name_exists = pnh_.searchParam("advertise_services", advertise_services_param_name);

    advertise_services_ = true;
    readParam(pnh_, advertise_services_param_name, advertise_services_, advertise_services_);

    if (advertise_services_ == true)
    {
      RCOMPONENT_INFO("Advertising services for component");

      //  ros::ServiceServer service =
      //        add_procedure_service_.advertiseService(pnh_, &ProcedureComponent::methodComponentCallbackManager,
      //        this);

      if (add_procedure_callback_manager_ ==
          NULL)  // we dont have a callback manager, advertise addProcedure as normal service
      {
        services_.push_back(
            pnh_.advertiseService(ProcedureComponentConstants::ADD, &ProcedureComponent::addProcedureNoConst, this));
        if (services_.back() == 0)
        {
          // error!
        }
      }
      else
      {
        // we have a callback manager, from a robot local control, so use it!
        add_procedure_service_.registerBoostFunctionServiceCallback(
            boost::bind(&ProcedureComponent::addProcedure, this, _1, _2));
        add_procedure_service_.setServiceName(ProcedureComponentConstants::ADD);
        ros::ServiceServer service = add_procedure_service_.advertiseService(pnh_, add_procedure_callback_manager_);
        services_.push_back(service);
        shifter_services_.push_back(&add_procedure_service_);
        /////      ros::ServiceServer service = add_procedure_service_.advertiseService(
        /////          pnh_, boost::bind(add_procedure_callback_manager_, _1,
        /////                            add_procedure_service_.getBridgeServiceCallbackFunction()));
        /////      services_.push_back(service);
        /////      shifter_services_.push_back(&add_procedure_service_);

        //    add_procedure_service_.registerServiceCallback(boost::bind(&ProcedureComponent::queryState, this, _1,
        //    _2));

        //      // add_procedure_callback_manager_ is a function with arguments:
        //      // * ros::ServiceEvent
        //      // * a function pointer
        //      // so we bind it to:
        //      // _1: which will be input argument
        //      // add_procedure_service_.getBridgeServiceCallbackFunction(): which is the callback
      }

      services_.push_back(
          pnh_.advertiseService(ProcedureComponentConstants::QUERY_STATE, &ProcedureComponent::queryState, this));
      if (services_.back() == 0)
      {
        // error!
      }

      services_.push_back(
          pnh_.advertiseService(ProcedureComponentConstants::PAUSE, &ProcedureComponent::pauseProcedure, this));
      if (services_.back() == 0)
      {
        // error!
      }

      services_.push_back(
          pnh_.advertiseService(ProcedureComponentConstants::RESUME, &ProcedureComponent::resumeProcedure, this));
      if (services_.back() == 0)
      {
        // error!
      }

      services_.push_back(
          pnh_.advertiseService(ProcedureComponentConstants::CANCEL, &ProcedureComponent<T>::cancelProcedure, this));
      if (services_.back() == 0)
      {
        // error!
      }
    }
    else
    {
      RCOMPONENT_INFO("Services for this component are NOT advertised");
    }
    return RComponent::rosSetup();
  }

  virtual int stop()
  {
    cancelAllProcedures();

    return GenericProcedureComponent::stop();
  }

public:
  // TODO: check if this functions can be protected or similar
  virtual bool queryState(procedures_msgs::ProcedureQuery::Request& request,
                          procedures_msgs::ProcedureQuery::Response& response)
  {
    //    if (request.header.id != -1 and
    //        not(current_procedure_.header.id == request.header.id or
    //            (pending_procedures_.size() > 0 and pending_procedures_.front().header.id == request.header.id)))
    //

    if (request.header.id != -1)
    {
      if (current_procedure_.header.id == request.header.id)
      {
        // DO NOTHING, ID's match!
      }
      else if (pending_procedures_.size() > 0 and pending_procedures_.front().header.id == request.header.id)
      {
        // DO NOTHING, ID's match!
      }
      else
      {
        RCOMPONENT_WARN_STREAM(LOG_PROCEDURE_STREAM << "You are asking for the state of id " << request.header.id
                                                    << " but my current id is " << current_procedure_.header.id);

        std::string error_message = "No matching header id";

        response.result.result = procedures_msgs::ProcedureResult::ERROR;
        response.result.message = error_message;

        RCOMPONENT_ERROR_STREAM(LOG_PROCEDURE_STREAM << error_message);
        return true;
      }
    }

    response.state = current_procedure_.state;
    response.result.result = procedures_msgs::ProcedureResult::OK;
    response.result.message = "Perfect";
    response.last_message.data = last_message_;

    return true;
  }

  // TODO does not accept const Request ???
  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response)
  {
    return false;
  }

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response)
  {
    return false;
  }

  virtual bool cancelAllProcedures()
  {
    return false;
  }

  virtual bool pauseProcedure(procedures_msgs::ProcedureQuery::Request& request,
                              procedures_msgs::ProcedureQuery::Response& response)
  {
    if (getState() != robotnik_msgs::State::READY_STATE)
    {
      // TODO: add test for this
      std::string error_message = "Cannot pause procedure because component is not at ReadyState";

      response.result.result = procedures_msgs::ProcedureResult::ERROR;
      response.result.message = error_message;
      RCOMPONENT_ERROR_STREAM(LOG_PROCEDURE_STREAM << error_message);
      return true;
    }

    current_procedure_.state.current_state = procedures_msgs::ProcedureState::PAUSE;
    current_procedure_.state.last_event = procedures_msgs::ProcedureState::PAUSED;

    response.state = current_procedure_.state;
    response.state.header = current_procedure_.header;
    response.result.result = procedures_msgs::ProcedureResult::OK;
    response.result.message = "Perfect";
    return true;
  }

  virtual bool resumeProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response)
  {
    return false;
  }

  bool addProcedureShifter(const service_shifter::ServiceShifter& request, service_shifter::ServiceShifter& response)
  {
    const typename T::Petition::Request req = request;
    typename T::Petition::Response res = response;

    bool callback_result = addProcedure(req, res);
    response = res;
    return callback_result;
  }

  // this one is needed because we cannot advertise a service with a callback that has the request argument as const.
  // there is no specilization of the serialization methods for it. so just by pass it.
  virtual bool addProcedureNoConst(typename T::Petition::Request& request, typename T::Petition::Response& response)
  {
    return addProcedure(request, response);
  }

  virtual bool addProcedure(const typename T::Petition::Request& request, typename T::Petition::Response& response)
  {
    if (getState() != robotnik_msgs::State::READY_STATE)
    {
      // TODO: add test for this
      std::string error_message = "Cannot add procedure because component is not at ReadyState";

      response.result.result = procedures_msgs::ProcedureResult::ERROR;
      response.result.message = error_message;
      RCOMPONENT_ERROR_STREAM(LOG_PROCEDURE_STREAM << error_message);
      return true;
    }

    // TODO: i dont like this way of checking if a procedure can be added or not

    if (isPreemptable() == false and
        current_procedure_.state.current_state != procedures_msgs::ProcedureState::FINISHED and
        current_procedure_.state.current_state != procedures_msgs::ProcedureState::UNKNOWN)
    {
      std::string error_message = "Cannot add procedure because component has unfinished procedures";

      response.result.result = procedures_msgs::ProcedureResult::ERROR;
      response.result.message = error_message;
      RCOMPONENT_ERROR_STREAM(LOG_PROCEDURE_STREAM << error_message);
      return true;
    }

    static int m = 0;
    if (isPreemptable() == true and
        current_procedure_.state.current_state != procedures_msgs::ProcedureState::FINISHED and
        current_procedure_.state.current_state != procedures_msgs::ProcedureState::UNKNOWN)
    {
      if (pending_procedures_.size() > 0)
      {
        std::string error_message = "Cannot add procedure because component has already a pending procedure and I can "
                                    "handle a queue of 2 (one running and one to preempt)";

        response.result.result = procedures_msgs::ProcedureResult::ERROR;
        response.result.message = error_message;
        RCOMPONENT_ERROR_STREAM(LOG_PROCEDURE_STREAM << error_message);
        return true;
      }
      T new_procedure;
      new_procedure.header.id = (++m);
      new_procedure.procedure = request.procedure;
      new_procedure.state.current_state = procedures_msgs::ProcedureState::QUEUED;
      new_procedure.state.last_event = procedures_msgs::ProcedureState::ADDED;

      t_step_transition_ = ros::Time::now();

      response.state = new_procedure.state;
      response.state.header = new_procedure.header;
      response.result.result = procedures_msgs::ProcedureResult::OK;
      RCOMPONENT_INFO_STREAM("Added goal as preempted: " << LOG_PROCEDURE_STREAM);

      pending_procedures_.resize(1);
      pending_procedures_[0] = new_procedure;
      return true;
    }

    else
    {  // TODO: add method to generate procedure id

      current_procedure_.header.id = (++m);
      current_procedure_.procedure = request.procedure;
      current_procedure_.state.current_state = procedures_msgs::ProcedureState::QUEUED;
      current_procedure_.state.last_event = procedures_msgs::ProcedureState::ADDED;

      t_step_transition_ = ros::Time::now();

      response.state = current_procedure_.state;
      response.state.header = current_procedure_.header;
      response.result.result = procedures_msgs::ProcedureResult::OK;
      RCOMPONENT_INFO_STREAM(LOG_PROCEDURE_STREAM);
      return true;
    }
    return false;  // this makes the method fail if the structure tree before is wrong
  }

  virtual int rosShutdown()
  {  // TODO: add test for this
    RComponent::rosShutdown();
    for (ros::ServiceServer& service : services_)
      service.shutdown();
    
    return 0;
  }

  virtual bool isRunningProcedure()
  {
    return current_procedure_.state.current_state == procedures_msgs::ProcedureState::RUNNING;
  }

  virtual bool hasPendingProcedures()
  {
    return current_procedure_.state.current_state != procedures_msgs::ProcedureState::FINISHED;
  }

  typename T::Type getCurrentProcedure()
  {
    return current_procedure_.procedure;
  }
  procedures_msgs::ProcedureState getCurrentState()
  {
    return current_procedure_.state;
  }

  virtual void setAborted(std::string msg)
  {
    current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
    current_procedure_.state.last_event = procedures_msgs::ProcedureState::ABORT;
    setLastMessage(msg, true);
  }

  virtual void setSucceed(std::string msg)
  {
    current_procedure_.state.current_state = procedures_msgs::ProcedureState::FINISHED;
    current_procedure_.state.last_event = procedures_msgs::ProcedureState::FINISH;
    setLastMessage(msg, true);
  }

  virtual std::string stepToString(int step)
  {
    return std::to_string(step);
  }

  virtual void switchToStep(int next_step)
  {
    // This method will be used inside each Procedure in order to change the current step
    if (next_step == current_step_)
      return;

    RCOMPONENT_INFO_STREAM("Moving from " << stepToString(current_step_) << " to " << stepToString(next_step));
    previous_step_ = current_step_;
    current_step_ = next_step;
    t_step_transition_ = ros::Time::now();
  }

  ros::Duration getElapsedTimeSinceLastStepTransition()
  {
    return ros::Time::now() - t_step_transition_;
  }

  virtual void convertResponseToServiceShifter(const procedures_msgs::ProcedureState& state,
                                               const procedures_msgs::ProcedureResult& result,
                                               service_shifter::ServiceShifter& shifter)

  {
    typename T::Petition::Response response;
    response.state = state;
    response.result = result;
    shifter = response;
  }

protected:
  // This NodeHandle is to access to the global namespace. It refers to the "namespace" in which the node is launched,
  // so it is good for accessing things like move_base from inside robot_local_control
  ros::NodeHandle gnh_;

  T current_procedure_;
  std::vector<T> pending_procedures_;

  bool advertise_services_;
  std::vector<ros::ServiceServer> services_;

  std::vector<service_shifter::GenericShifterServiceServer*> shifter_services_;

  service_shifter::ShifterServiceServer<procedures_msgs::ProcedureQuery> query_service_;
  service_shifter::ShifterServiceServer<typename T::Petition> add_procedure_service_;

  std::string last_message_;
  int current_step_, previous_step_;
  ros::Time t_step_transition_;

protected:
  bool methodComponentCallbackManager(
      const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>& event,
      boost::function<bool(const service_shifter::ServiceShifter&, service_shifter::ServiceShifter&)> recallback)
  {
    RCOMPONENT_WARN_STREAM("");
    return recallback(event.getRequest(), event.getResponse());
  }

  void setLastMessage(std::string msg, bool verbose = false)
  {
    last_message_ = msg;
    if (verbose)
      RCOMPONENT_INFO_STREAM(LOG_PROCEDURE_STREAM << msg);
  }
};
}
#endif  //__PROCEDURE_COMPONENT_H

