
"use strict";

let SwitchMap = require('./SwitchMap.js');
let Charge = require('./Charge.js');
let PostPick = require('./PostPick.js');
let MissionParamBool = require('./MissionParamBool.js');
let EnterShower = require('./EnterShower.js');
let PostPlace = require('./PostPlace.js');
let FindMagneticGuide = require('./FindMagneticGuide.js');
let PrePick = require('./PrePick.js');
let BarcodePickPlace = require('./BarcodePickPlace.js');
let MissionParamString = require('./MissionParamString.js');
let Missions = require('./Missions.js');
let RobotStatus = require('./RobotStatus.js');
let PrePlace = require('./PrePlace.js');
let GoToGPS = require('./GoToGPS.js');
let Status = require('./Status.js');
let MissionParamFloat = require('./MissionParamFloat.js');
let Twist2D = require('./Twist2D.js');
let MissionStatus = require('./MissionStatus.js');
let MagneticNavigation = require('./MagneticNavigation.js');
let PointGPS = require('./PointGPS.js');
let Move = require('./Move.js');
let MagneticPlace = require('./MagneticPlace.js');
let MissionCommand = require('./MissionCommand.js');
let LeaveShower = require('./LeaveShower.js');
let SignalManager = require('./SignalManager.js');
let GoTo = require('./GoTo.js');
let EnterGlovebox = require('./EnterGlovebox.js');
let Place = require('./Place.js');
let LocalizationStatus = require('./LocalizationStatus.js');
let EnterLift = require('./EnterLift.js');
let LeaveLift = require('./LeaveLift.js');
let MagneticGoTo = require('./MagneticGoTo.js');
let GoToNode = require('./GoToNode.js');
let NavigationStatus = require('./NavigationStatus.js');
let StatusArray = require('./StatusArray.js');
let Pick = require('./Pick.js');
let MagneticPick = require('./MagneticPick.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let SetElevator = require('./SetElevator.js');
let LeaveMagneticGuide = require('./LeaveMagneticGuide.js');
let Dock = require('./Dock.js');
let SensorStatus = require('./SensorStatus.js');
let GoToTag = require('./GoToTag.js');
let MissionParamInt = require('./MissionParamInt.js');
let ControllerStatus = require('./ControllerStatus.js');
let Uncharge = require('./Uncharge.js');

module.exports = {
  SwitchMap: SwitchMap,
  Charge: Charge,
  PostPick: PostPick,
  MissionParamBool: MissionParamBool,
  EnterShower: EnterShower,
  PostPlace: PostPlace,
  FindMagneticGuide: FindMagneticGuide,
  PrePick: PrePick,
  BarcodePickPlace: BarcodePickPlace,
  MissionParamString: MissionParamString,
  Missions: Missions,
  RobotStatus: RobotStatus,
  PrePlace: PrePlace,
  GoToGPS: GoToGPS,
  Status: Status,
  MissionParamFloat: MissionParamFloat,
  Twist2D: Twist2D,
  MissionStatus: MissionStatus,
  MagneticNavigation: MagneticNavigation,
  PointGPS: PointGPS,
  Move: Move,
  MagneticPlace: MagneticPlace,
  MissionCommand: MissionCommand,
  LeaveShower: LeaveShower,
  SignalManager: SignalManager,
  GoTo: GoTo,
  EnterGlovebox: EnterGlovebox,
  Place: Place,
  LocalizationStatus: LocalizationStatus,
  EnterLift: EnterLift,
  LeaveLift: LeaveLift,
  MagneticGoTo: MagneticGoTo,
  GoToNode: GoToNode,
  NavigationStatus: NavigationStatus,
  StatusArray: StatusArray,
  Pick: Pick,
  MagneticPick: MagneticPick,
  Pose2DStamped: Pose2DStamped,
  SetElevator: SetElevator,
  LeaveMagneticGuide: LeaveMagneticGuide,
  Dock: Dock,
  SensorStatus: SensorStatus,
  GoToTag: GoToTag,
  MissionParamInt: MissionParamInt,
  ControllerStatus: ControllerStatus,
  Uncharge: Uncharge,
};
