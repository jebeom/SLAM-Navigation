// Auto-generated. Do not edit!

// (in-package robot_local_control_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BarcodePickPlace {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.barcode_id = null;
      this.position = null;
    }
    else {
      if (initObj.hasOwnProperty('barcode_id')) {
        this.barcode_id = initObj.barcode_id
      }
      else {
        this.barcode_id = '';
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BarcodePickPlace
    // Serialize message field [barcode_id]
    bufferOffset = _serializer.string(obj.barcode_id, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = _serializer.uint32(obj.position, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BarcodePickPlace
    let len;
    let data = new BarcodePickPlace(null);
    // Deserialize message field [barcode_id]
    data.barcode_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.barcode_id);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robot_local_control_msgs/BarcodePickPlace';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3c6153cdf55196f3ee66729d0429b068';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string BARCODE_ID_FRONT = front
    string BARCODE_ID_REAR = rear
    
    string barcode_id # front, rear
    uint32 position # In mm
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BarcodePickPlace(null);
    if (msg.barcode_id !== undefined) {
      resolved.barcode_id = msg.barcode_id;
    }
    else {
      resolved.barcode_id = ''
    }

    if (msg.position !== undefined) {
      resolved.position = msg.position;
    }
    else {
      resolved.position = 0
    }

    return resolved;
    }
};

// Constants for message
BarcodePickPlace.Constants = {
  BARCODE_ID_FRONT: 'front',
  BARCODE_ID_REAR: 'rear',
}

module.exports = BarcodePickPlace;
