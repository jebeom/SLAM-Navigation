
"use strict";

let GoToPetition = require('./GoToPetition.js')
let GoToNodePetition = require('./GoToNodePetition.js')
let SwitchMapPetition = require('./SwitchMapPetition.js')
let MagneticPlacePetition = require('./MagneticPlacePetition.js')
let SetPose2DStamped = require('./SetPose2DStamped.js')
let ChargePetition = require('./ChargePetition.js')
let EnterGloveboxPetition = require('./EnterGloveboxPetition.js')
let SetElevatorPetition = require('./SetElevatorPetition.js')
let MagneticGoToPetition = require('./MagneticGoToPetition.js')
let SimpleGoToWithValidation = require('./SimpleGoToWithValidation.js')
let EnterLiftPetition = require('./EnterLiftPetition.js')
let PrePickPetition = require('./PrePickPetition.js')
let EnterShowerPetition = require('./EnterShowerPetition.js')
let MissionCommandPetition = require('./MissionCommandPetition.js')
let BarcodePickPlacePetition = require('./BarcodePickPlacePetition.js')
let Cancel = require('./Cancel.js')
let MovePetition = require('./MovePetition.js')
let DockPetition = require('./DockPetition.js')
let LeaveLiftPetition = require('./LeaveLiftPetition.js')
let SetGoToPetition = require('./SetGoToPetition.js')
let PostPickPetition = require('./PostPickPetition.js')
let GoToGPSPetition = require('./GoToGPSPetition.js')
let PrePlacePetition = require('./PrePlacePetition.js')
let PlacePetition = require('./PlacePetition.js')
let MagneticNavigationPetition = require('./MagneticNavigationPetition.js')
let SaveMap = require('./SaveMap.js')
let LeaveShowerPetition = require('./LeaveShowerPetition.js')
let LeaveMagneticGuidePetition = require('./LeaveMagneticGuidePetition.js')
let UnchargePetition = require('./UnchargePetition.js')
let SetFrameID = require('./SetFrameID.js')
let PickPetition = require('./PickPetition.js')
let SetDefaultModule = require('./SetDefaultModule.js')
let GoToTagPetition = require('./GoToTagPetition.js')
let StatusPetition = require('./StatusPetition.js')
let SetControlState = require('./SetControlState.js')
let BatteryExchangePetition = require('./BatteryExchangePetition.js')
let MagneticPickPetition = require('./MagneticPickPetition.js')
let GetEnvironment = require('./GetEnvironment.js')
let SwitchModule = require('./SwitchModule.js')
let SetEnvironment = require('./SetEnvironment.js')
let MissionPetition = require('./MissionPetition.js')
let PostPlacePetition = require('./PostPlacePetition.js')
let FindMagneticGuidePetition = require('./FindMagneticGuidePetition.js')

module.exports = {
  GoToPetition: GoToPetition,
  GoToNodePetition: GoToNodePetition,
  SwitchMapPetition: SwitchMapPetition,
  MagneticPlacePetition: MagneticPlacePetition,
  SetPose2DStamped: SetPose2DStamped,
  ChargePetition: ChargePetition,
  EnterGloveboxPetition: EnterGloveboxPetition,
  SetElevatorPetition: SetElevatorPetition,
  MagneticGoToPetition: MagneticGoToPetition,
  SimpleGoToWithValidation: SimpleGoToWithValidation,
  EnterLiftPetition: EnterLiftPetition,
  PrePickPetition: PrePickPetition,
  EnterShowerPetition: EnterShowerPetition,
  MissionCommandPetition: MissionCommandPetition,
  BarcodePickPlacePetition: BarcodePickPlacePetition,
  Cancel: Cancel,
  MovePetition: MovePetition,
  DockPetition: DockPetition,
  LeaveLiftPetition: LeaveLiftPetition,
  SetGoToPetition: SetGoToPetition,
  PostPickPetition: PostPickPetition,
  GoToGPSPetition: GoToGPSPetition,
  PrePlacePetition: PrePlacePetition,
  PlacePetition: PlacePetition,
  MagneticNavigationPetition: MagneticNavigationPetition,
  SaveMap: SaveMap,
  LeaveShowerPetition: LeaveShowerPetition,
  LeaveMagneticGuidePetition: LeaveMagneticGuidePetition,
  UnchargePetition: UnchargePetition,
  SetFrameID: SetFrameID,
  PickPetition: PickPetition,
  SetDefaultModule: SetDefaultModule,
  GoToTagPetition: GoToTagPetition,
  StatusPetition: StatusPetition,
  SetControlState: SetControlState,
  BatteryExchangePetition: BatteryExchangePetition,
  MagneticPickPetition: MagneticPickPetition,
  GetEnvironment: GetEnvironment,
  SwitchModule: SwitchModule,
  SetEnvironment: SetEnvironment,
  MissionPetition: MissionPetition,
  PostPlacePetition: PostPlacePetition,
  FindMagneticGuidePetition: FindMagneticGuidePetition,
};
