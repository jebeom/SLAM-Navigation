/*! \class MotorDrive
 *  \file MotorDrive.h
 *	\author Robotnik Automation S.L.L
 *	\version 1.0
 *	\date 2012
 *  \brief Class to manage the communication with the driver via CANOpen
 * (C) 2012 Robotnik Automation, SLL
 *  All rights reserved.
 */

#ifndef _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
#define _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_

#include <robotnik_base_hw_lib/Component.h>
#include <robotnik_base_hw_lib/PCan.h>
#include <vector>
#include <robotnik_base_hw_lib/Watchdog.h>
#include <numeric>

#define TRAC_GEAR 12.5                            // traction gearbox 1:12.52  - 24VDC Robotnik Hub
#define MOTOR_WHEEL_DIAMETER 0.1524               // motorwheel diameter 6 inch minus deformation [M]
#define PPS_REV_VEL 48.0                          // pulses per revolution: 16 poles * 3 hall sensors
#define QUAD_VEL 1.0                              // Encoder's quadrature
#define COUNTS_PER_REV_VEL PPS_REV_VEL* QUAD_VEL  // Encoder counts per revolution

#define PPS_REV_POS 1024.0                        // pulses per revolution position axis
#define QUAD_POS 4.0                              // Encoder's quadrature
#define COUNTS_PER_REV_POS PPS_REV_POS* QUAD_POS  // Encoder counts per revolution

#define MOTOR_PI 3.14159265358979323846
#define REV_TO_METER MOTOR_WHEEL_DIAMETER* MOTOR_PI  // 1 rev -> x meters ( Diameter * Pi)
#define METER_TO_REV 1.0 / REV_TO_METER              // Constant to convert meters into revolutions
#define SPEED_SCALE_FACTOR 6.5536                    // Driver scale factor
#define NODEGUARD_TIME 200                           // Time (ms) to control the communication with the driver
#define NODEGUARD_FACTOR 5                           // factor to mult
#define HEARTBEAT_TIMER 2000                         // milliseconds
#define EVENT_RECOVERY_TIME 1000                     // milliseconds
#define BATTERY_ANALOG_INPUT 1                       // Analog input used to measure the battery
#define DEFAULT_DIGITAL_INPUT_ESTOP 1
//#define DIGITAL_INPUT_ESTOP 0x01
#define NMT_TIMEOUT 2  // Max timeout (seconds) on the communication with the drivers
#define STATUS_REGISTER_WORDS 7
#define MAX_CTRL_PARAMS 9
#define READ_SDO_THREAD_HZ 5.0
#define CONTROL_COMMUNICATION_THREAD_HZ 5.0
#define MAX_CAN_ID 40 // Limits the max number of nodes in the bus as well as the ID. The theoretical number is 127

namespace robotnik_base_hw_lib
{
//! Main function to execute into test secondary thread
void* AuxMotorDriveControlCommunicationThread(void* threadParam);
//! Main function to execute into the third thread
void* AuxMotorDriveReadSDOMessagesThread(void* threadParam);

//! Class MotorDrive
class MotorDrive : public Component
{
  friend void* AuxMotorDriveControlCommunicationThread(void* threadParam);
  friend void* AuxMotorDriveReadSDOMessagesThread(void* threadParam);

private:
  //! Use position instead of velocity for motor velocity calculation
  bool firstPoseRead;
  ros::Time lastReadTime;
public:
  //! Internal drive status
  enum DriveState
  {
    UNKNOWN,
    SWITCH_ON_DISABLED,
    NOT_READY_TO_SWITCH_ON,
    READY_TO_SWITCH_ON,
    OPERATION_DISABLED,
    OPERATION_ENABLED,
    FAULT,
    FAULT_REACTION_ACTIVE,
    UNDER_VOLTAGE,
    SWITCHED_ON,
    QUICK_STOP
  };

  //! Types of CAN messages
  enum CANMessage
  {
    // Real CAN Object messages
    CONTROL_WORD_MSG = 0x6040,
    STATUS_WORD_MSG = 0x6041,
    TARGET_POSITION_MSG = 0x607A,
    ACTUAL_POSITION_MSG = 0x6064,
    TARGET_VELOCITY_MSG = 0x60FF,
    ACTUAL_VELOCITY_MSG = 0x606C,
    DIGITAL_OUTPUTS_MSG = 0x2001,
    DIGITAL_INPUTS_MSG = 0x2023,
    ANALOG_INPUTS_MSG = 0x201A,
    MODE_OF_OPERATION_MSG = 0x6060,
    MODE_OF_OPERATION_DISPLAY_MSG = 0x6061,
    HOME_OFFSET_MSG = 0x607C,
    HOME_METHOD_MSG = 0x6098,
    HOME_SPEED_MSG = 0x6099,
    CONF_RPDO1_MSG = 0x1400,
    CONF_RPDO2_MSG = 0x1401,
    CONF_RPDO3_MSG = 0x1402,
    CONF_RPDO4_MSG = 0x1403,
    CONF_RPDO5_MSG = 0x1404,
    CONF_RPDO6_MSG = 0x1405,
    CONF_RPDO21_MSG = 0x1414,
    CONF_RPDO22_MSG = 0x1415,
    CONF_RPDO1_MAP_MSG = 0x1600,
    CONF_RPDO2_MAP_MSG = 0x1601,
    CONF_RPDO3_MAP_MSG = 0x1602,
    CONF_RPDO4_MAP_MSG = 0x1603,
    CONF_RPDO5_MAP_MSG = 0x1604,
    CONF_RPDO6_MAP_MSG = 0x1605,
    CONF_RPDO21_MAP_MSG = 0x1614,
    CONF_RPDO22_MAP_MSG = 0x1615,

    CONF_TPDO1_MSG = 0x1800,
    CONF_TPDO2_MSG = 0x1801,
    CONF_TPDO3_MSG = 0x1802,
    CONF_TPDO4_MSG = 0x1803,
    CONF_TPDO5_MSG = 0x1804,
    CONF_TPDO6_MSG = 0x1805,
    CONF_TPDO21_MSG = 0x1814,
    CONF_TPDO22_MSG = 0x1815,
    CONF_TPDO26_MSG = 0x1819,
    CONF_TPDO1_MAP_MSG = 0x1A00,
    CONF_TPDO2_MAP_MSG = 0x1A01,
    CONF_TPDO3_MAP_MSG = 0x1A02,
    CONF_TPDO4_MAP_MSG = 0x1A03,
    CONF_TPDO5_MAP_MSG = 0x1A04,
    CONF_TPDO6_MAP_MSG = 0x1A05,
    CONF_TPDO21_MAP_MSG = 0x1A14,
    CONF_TPDO22_MAP_MSG = 0x1A15,
    CONF_TPDO26_MAP_MSG = 0x1A19,


    DRIVE_STATUS_MSG = 0x2002,
    GUARD_TIME_MSG = 0x100C,
    LIFE_TIME_FACTOR_MSG = 0x100D,
    EVENT_ACTION_MSG = 0x2065,
    EVENT_RECOVERY_TIME_MSG = 0x2066,
    HEARTBEAT_CONSUMER_MSG = 0x1016,
    ACTUAL_CURRENT_MSG = 0x6077,
    DC_BUS_MSG = 0x200F,
    CURRENT_LOOP_GAIN_MSG = 0x2034,
    VELOCITY_LOOP_CONTROL_MSG = 0x2036,

    // Artificial Messages created for the application
    HEARTBEAT_MSG = -42,
    PEAK_CURRENT_LIMIT_AMPS_MSG = -50,
    PEAK_CURRENT_LIMIT_SECS_MSG = -51,
    CONTINUOUS_CURRENT_LIMIT_MSG = -52,
    CURRENT_FOLDBACK_TIME_MSG = -53,
    GS0_VELOCITY_LOOP_KP_MSG = -54,
    GS0_VELOCITY_LOOP_KI_MSG = -55,
    GS0_VELOCITY_LOOP_KD_MSG = -56,
    GS0_VELOCITY_LOOP_ACCEL_FEED_FORWARD_MSG = -57,
    VELOCITY_LOOP_INTEGRATOR_DECAY_MSG = -58,
    CURRENT_LOOP_GAIN_KP_MSG = -1111,
    CURRENT_LOOP_GAIN_KI_MSG = -49,
    SYNC_MSG = -1,
    START_COMM_MSG = -2,
    RESET_COMM_MSG = -3,
    RESET_NODE_MSG = -4,
    STOP_COMM_MSG = -5,
    PREOPERATIONAL_COMM_MSG = -6,

    SWITCH_ON_MSG = -7,
    DISABLE_VOLT_MSG = -8,
    NODEGUARD_MSG = -9,
    ENABLE_OP_MSG = -12,
    RESET_MSG = -13,
    SHUTDOWN_MSG = -14,
    QUICK_STOP_MSG = -15,
    START_HOME_MSG = -16,
    STOP_HOME_MSG = -17,

    HOME_SPEED1_MSG = -20,
    HOME_SPEED2_MSG = -21,

    VELOCITY_PDO_MSG = -100,
    POSITION_PDO_MSG = -200,
    CONTROL_WORD_PDO_MSG = -300,

  };

  //! Status word indicators
  enum StatusWordIndicator
  {
    SW_READY_TO_SWITCH_ON = 0,
    SW_SWITCHED_ON = 1,
    SW_OP_ENABLED = 2,
    SW_FAULT = 3,
    SW_VOLTAGE_ENABLED = 4,
    SW_QUICK_STOP = 5,
    SW_SWITCH_ON_DISABLED = 6,
    SW_WARNING = 7,
    SW_DELAY = 8,
    SW_TARGET_REACHED = 10,
    SW_HOME_ATTAINED = 12,
    SW_HOMING_ERROR = 13,
    SW_CAPTURE = 14,
    SW_NUMBER = 16
  };
  //! Modes of operation of the driver
  enum ModeOfOperation
  {
    UNKNOWN_MODE = 0xBB,
    PROFILE_POSITION_MODE = 0x01,
    PROFILE_VELOCITY_MODE = 0x03,
    PROFILE_TORQUE_MODE = 0x04,
    HOMING_MODE = 0x06,
    INTERPOLATED_POSITION_MODE = 0x07,
    CYCLIC_SYNC_POSITION_MODE = 0x08,
    CYCLIC_SYNC_VELOCITY_MODE = 0x09,
    CICLYC_SYNC_TORQUE_MODE = 0x0A,
    CUSTOM_CONFIGURED_MODES = 0xFF
  };
  //! Homing methods
  enum HomingMethod
  {
    HOME_METHOD_NEGATIVE = 0x01,
    HOME_METHOD_POSITIVE = 0x02
  };
  enum PDOTransmissionType
  {
    SYNC_ACYCLIC = 0,
    SYCN_RTR = 0xFC,
    ASYNC_RTR = 0xFD,
    ASYNC = 0xFE
  };
  // Possible event actions when an error is produced
  enum EventActionValues
  {
    EVENT_NO_ACTION = 0,
    EVENT_DISABLE_POWER = 0x01,
    EVENT_DISABLE_POSITIVE = 0x02,
    EVENT_DISABLE_NEGATIVE = 0x03,
    EVENT_DYNAMIC_BRAKE = 0x04,
    EVENT_POSITIVE_STOP = 0x05,
    EVENT_NEGATIVE_STOP = 0x06,
    EVENT_STOP = 0x07,
    EVENT_BRAKE_THEN_DISABLE_BRIDGE = 0x08,
    EVENT_BRAKE_THEN_DYNAMIC_BRAKE = 0x09,
    EVENT_BRAKE_AND_DISABLE_BRIDGE = 0x10,
    EVENT_BRAKE_AND_DYNAMIC_BRAKE = 0x11
  };
  enum DriveStatusFlags
  {
    // DRIVE BRIDGE STATUS
    DS_BRIDGE_ENABLED = 0,
    DS_DYNAMIC_BRAKE_ENABLED = 1,
    DS_SHUNT_ENABLED = 2,
    DS_POSITIVE_STOP_ENABLED = 3,
    DS_NEGATIVE_STOP_ENABLED = 4,
    DS_POSITIVE_TORQUE_INHIBIT_ACTIVE = 5,
    DS_NEGATIVE_TORQUE_INHIBIT_ACTIVE = 6,
    DS_EXTERNAL_BRAKE_ACTIVE = 7,
    // DRIVE PROTECTION STATUS
    DS_DRIVE_RESET = 8,
    DS_DRIVE_INTERNAL_ERROR = 9,
    DS_SHORT_CIRCUIT = 10,
    DS_CURRENT_OVERSHOOT = 11,
    DS_UNDER_VOLTAGE = 12,
    DS_OVER_VOLTAGE = 13,
    DS_DRIVER_OVER_TEMPERATURE = 14,
    // SYSTEM PROTECTION STATUS
    DS_PARAMETER_RESTORE_ERROR = 15,
    DS_PARAMETER_STORE_ERROR = 16,
    DS_INVALID_HALL_STATE = 17,
    DS_PHASE_SYNC_ERROR = 18,
    DS_MOTOR_OVER_TEMPERATURE = 19,
    DS_PHASE_DETECTION_FAULT = 20,
    DS_FEEDBACK_SENSOR_ERROR = 21,
    DS_MOTOR_OVER_SPEED = 22,
    DS_MAX_MEASURED_POSITION = 23,
    DS_MIN_MEASURED_POSITION = 24,
    DS_COMMUNICATION_ERROR = 25,
    // DRIVE SYSTEM STATUS 1
    DS_LOG_ENTRY_MISSED = 26,
    DS_COMMANDED_DISABLE = 27,
    DS_USER_DISABLE = 28,
    DS_POSITIVE_INHIBIT = 29,
    DS_NEGATIVE_INHIBIT = 30,
    DS_CURRENT_LIMITING = 31,
    DS_CONTINUOUS_CURRENT = 32,
    DS_CURRENT_LOOP_SATURED = 33,
    DS_USER_UNDER_VOLTAGE = 34,
    DS_USER_OVER_VOLTAGE = 35,
    DS_NONSINUSOIDAL_COMMUTATION = 36,
    DS_PHASE_DETECTION = 37,
    DS_USER_AUXILIARY_DISABLE = 38,
    DS_SHUNT_REGULATOR = 39,
    DS_PHASE_DETECTION_COMPLETE = 40,
    // DRIVE SYSTEM STATUS 2
    DS_ZERO_VELOCITY = 41,
    DS_AT_COMMAND = 42,
    DS_VELOCITY_FOLLOWING_ERROR = 43,
    DS_POSITIVE_TARGET_VELOCITY_LIMIT = 44,
    DS_NEGATIVE_TARGET_VELOCITY_LIMIT = 45,
    DS_COMMAND_LIMITER_ACTIVE = 46,
    DS_IN_HOME_POSITION = 47,
    DS_POSITON_FOLLOWING_ERROR = 48,
    DS_MAX_TARGET_POSITION_LIMIT = 49,
    DS_MIN_TARGET_POSITION_LIMIT = 50,
    DS_LOAD_MEASURED_POSITION = 51,
    DS_LOAD_TARGET = 52,
    DS_HOMING_ACTIVE = 53,
    DS_HOMING_COMPLETE = 54,
    // DRIVE SYSTEM STATUS 3
    DS_PVT_BUFFER_FULL = 55,
    DS_PVT_BUFFER_EMPTY = 56,
    DS_PVT_BUFFER_THRESHOLD = 57,
    DS_PVT_BUFFER_FAILURE = 58,
    DS_PVT_BUFFER_EMPTY_STOP = 59,
    DS_PVT_BUFFER_SEQUENCE_ERROR = 60,
    DS_COMMANDED_STOP = 61,
    DS_USER_QUICKSTOP = 62,
    DS_COMMANDED_POSITIVE_LIMIT = 63,
    DS_COMMANDED_NEGATIVE_LIMIT = 64,
    // ACTIVE CONFIGURATION STATUS
    DS_ABSOLUTE_POSITION_VALID = 65,
    DS_POSITIVE_STOP_ACTIVE = 66,
    DS_NEGATIVE_STOP_ACTIVE = 67,
    // TOTAL MESSAGES
    DS_NUMBER = 68
  };

  enum
  {
    DRIVE_STATUS_FLAG_TIMER =
        3000000,  // 3000000 uSecs = 3s Timer to generate an alarm when a drive status flag is active
    DRIVE_STATUS_CONTROL_TIMER = 500000,  // 500000 uSecs = 50 ms = 0.05 s Timer to try to switch to the desired status
    DRIVE_STATUS_PID_CONTROL_TIMER = 1000000,

  };


  enum ControlMode
  {
    CONTROL_MODE_VELOCITY = 1000,
    CONTROL_MODE_POSITION = 2000,
    CONTROL_MODE_TORQUE = 3000,
  };


  // class to save the pdo ids and config
  class PDO
  {
  public:
    PDO()
    {
      RPDO1 = RPDO2 = RPDO3 = RPDO4 = RPDO5 = RPDO6 = RPDO21 = RPDO22 = 0x00;
      RPDO23 = RPDO24 = RPDO25 = RPDO26 = RPDO27 = RPDO28 = 0x0;
      TPDO1 = TPDO2 = TPDO3 = TPDO4 = TPDO5 = TPDO6 = TPDO21 = TPDO22 = 0x0;
      TPDO23 = TPDO24 = TPDO25 = TPDO26 = TPDO27 = TPDO28 = 0x0;
      VELOCITY_PDO_MSG_ID = 0x0;
      POSITION_PDO_MSG_ID = 0x0;
      CONTROL_WORD_PDO_MSG_ID = 0x0;
    };
    ~PDO(){};

    unsigned int RPDO1, RPDO2, RPDO3, RPDO4, RPDO5, RPDO6, RPDO21, RPDO22;
    unsigned int RPDO23, RPDO24, RPDO25, RPDO26, RPDO27, RPDO28;
    // TPDO
    unsigned int TPDO1, TPDO2, TPDO3, TPDO4, TPDO5, TPDO6, TPDO21, TPDO22;
    unsigned int TPDO23, TPDO24, TPDO25, TPDO26, TPDO27, TPDO28;

    // Links a general PDO command like velocity, position,... with a specific RPDO
    unsigned int VELOCITY_PDO_MSG_ID,POSITION_PDO_MSG_ID,CONTROL_WORD_PDO_MSG_ID;

  };

  // Struct shared by all the MotorDrives
  // Not all the fields are used by all the types of MotorDrives
  typedef struct KinematicParams
  {
    bool calculate_vel_using_pose;
    double wheel_diameter;
    double gearbox_ratio;
    bool has_encoder;
    double encoder_resolution;
    double spin;
    double offset;
    bool home_required;
    int home_method;
    bool home_at_startup;
    int low_position_limit;
    int high_position_limit;
    int potentiometer_analog_input;
    double potentiometer_voltage_calibration;
    double rps2ref_;  // K to convert from rads per second to motor ref (vel)
    double ref2rps_;  // K to convert from motor ref to rps (vel)
    double rad2ref_;  // K to convert from radians to motor ref (pos)
    double ref2rad_;  // K to convert from motor ref to radians (pos)
    double control_power_consumption; // 
  } KinematicParams;

  typedef struct IoParams
  {
    int inputs_per_driver;
    int outputs_per_driver;
    int analog_inputs_per_driver;
  } IoParams;

  typedef struct ControlParams
  {
    double current_kp;
    double current_ki;
    double peak_current_limit_amps;
    double peak_current_limit_secs;
    double current_foldbacks_secs;
    double velocity_kp;
    double velocity_ki;
    double velocity_kd;
    double continuous_current_limit;
    double max_rated_peak_current_drive;

  } ControlParams;

  typedef struct CommunicationConfiguration
  {
    int16_t guard_time; // ms
    uint8_t life_time_factor;

  } CommunicationConfiguration;

  //! Struct to store the value of digital inputs / outputs
  typedef struct Digital
  {
    //! Value for a maximum of 32 I/O
    unsigned int uiValue;
    //! Value of I/O using a vector
    bool bValue[32];
  } Digital;

  //! Struct used to configure the PDO mapping object
  typedef struct PdoMappingStructure
  {
    uint16_t index;
    uint8_t subindex;
    uint8_t length;
  } PdoMappingStructure;

protected:
  //! CAN device
  PCan* canDev;

  //! Can identifier
  byte CanId;
  //! Digital Inputs
  Digital digitalInputs;
  //! Digital Outputs (Desired value and read value from device)
  Digital digitalOutputs, digitalRealOutputs;

  //! Number of digital outputs
  unsigned int uiNumOfDigOut;
  //! Number of digital inputs
  unsigned int uiNumOfDigIn;
  //! Number of analog inputs
  unsigned int uiNumOfAnagIn;

  //! CAN communication status
  CommunicationStatus commStatus;
  //! Contains the values of the analog inputs
  std::vector<float> dAnalogInputs;
  //! Time of the last NodeGuard reply from the drive
  struct timespec tNodeGuardReply;
  //! Internal status of the drive
  DriveState dsState;
  //! Internal desired status of the drive
  DriveState dsDesiredState;
  //! Internal desired status of the drive sent by the user 
  DriveState dsUserDesiredState;
  //! Temperature of the drive
  double dTemperature;
  //! Velocity control proportional gain Kp
  double dVelKp;
  //! Velocity control integral gain Ki
  double dVelKi;
  //! Velocity control differential gain Kd
  double dVelKd;
  //! Status' flags of the drive
  bool bStatusWord[16];
  //! Drive Status flags (provided by CAN object 0x2002h)
  int16_t iDriveStatus[STATUS_REGISTER_WORDS];
  //! Manufacturer register status' flags of the drive. Flag for all the drive status bit provided by CAN 0x2002h object
  bool bStatusRegister[DS_NUMBER], bLastStatusRegister[DS_NUMBER];
  //! Vector to control the duration of an active flag to avoid too many logs
  struct timespec tStatusRegisterTimer[DS_NUMBER];
  //! Mascara con los flags que hay que controlar de forma peridica
  bool bStatusRegisterMask[DS_NUMBER];
  //! Controla que se hayan leido todos los status register
  bool bStatusRegisterRead[STATUS_REGISTER_WORDS];
  //! Flag para la lectura del registro de estado del driver
  bool bRegisterError;
  //! Flag to force the reset of the driver
  bool bForceReset;
  //! Delay between consecutive CAN transmissions (nanoseconds)
  static const unsigned int uiDelayTrans;
  //! Current Mode of operation of the drive
  int modModeOfOperation;
  //! Mode of operation to set depending on control_mode
  int modDesiredModeOfOperation;
  //! Actual Velocity ref of the motor
  int32_t iActualVelocityRef;
  //! Position ref of the motor
  int32_t iActualPositionRef;
  int32_t iLastActualPositionRef;
  float fActualVelocityUsingPosition;
  //! Torque ref of the motor
  int32_t iActualTorqueRef;
  //! Target Velocity ref of the motor
  int32_t iTargetVelocityRef;
  int32_t iLastTargetVelocityRef;
  //! Target Position ref of the motor
  int32_t iTargetPositionRef;
  //! Target Torque ref of the motor
  int32_t iTargetTorqueRef;
  //! Set when the homing method has been correctly executed
  bool bHomingComplete;
  //! Flag to set the begining of the homing
  bool bHoming;

  //! Set when homing is not needed (because it has been executed or has been done previously)
  bool bHasAbsolutePositionValid;
  bool bHadAbsolutePositionValidInThePast;

  //! Flag that shows DS_USER_DISABLE value
  bool bUserDisable;
  ////! Flag that shows DS_QUICK_STOP value
  bool bUserQuickstop;
  //! Timer to control the transitions of internal drive state
  struct timespec tControlWord;
  //! Timer to control the transitions of internal drive transitions
  struct timespec tStatusWordTransitionTime;
  //! Flags to read the analog inputs
  std::vector<bool> bAnalogEnable;
  //! Value of the instant consumed current, and the average (every second)
  double dInstantCurrent, dAverageCurrent;
  //! Value of the instant battery value, and the average (every second)
  double dInstantBattery, dAverageBattery;
  //! Value of the DC Bus Voltage
  double dDCBusVoltage;
  //! Emergency Stop Push/Release to Reset
  bool bEmergencyStopToReset;
  bool bHasPositionLimits;
  //! Parameters of the servo amplifier control loop
  ControlParams motor_ctrl_params;

  //! Parameters of Kinematics
  KinematicParams motor_kin_params;

  //! Parameters of IO Parameters
  IoParams motor_io_params;
  //!
  std::map<std::string, Watchdog> message_watchdog;
  //! map with the active errors
  std::map<int,std::string> active_errors;


  // Control mode or type of controller (Velocity, Position,...)
  ControlMode control_mode;

  PDO pdo_params;
  // Saves infor related with the current configuration
  CommunicationConfiguration communication_configuration;
  // Saves current softare version
  std::string software_version;
  // Array to save N values the potentiometer during the initialization
  std::vector<double> dPotentiometerValuesArray;
  unsigned int iMinNumberOfPotentiometerValues;
  
  ros::Time t_control_motor_consumption_init_transition_time;
  int iControlMotorConsumptionState;
  //! Flag active once the offset has been calculated
  bool offset_calculated;

public:
  //! public constructor
  MotorDrive(byte can_id, PCan* can_device, double desired_hz, KinematicParams kin_params, ControlParams ctrl_params,
             IoParams io_params, ControlMode control_mode);
  //! public constructor
  ~MotorDrive();
  //! Setups the component
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue Setup();
  //! Closes and frees the reserved resources
  //! @return OK
  //! @return ERROR if fails when closes the devices
  //! @return RUNNING if the component is running
  //! @return NOT_INITIALIZED if the component is not initialized
  virtual Component::ReturnValue ShutDown();
  //! Starts the control thread of the component and its subcomponents
  //! @return OK
  //! @return ERROR starting the thread
  //! @return RUNNING if it's already running
  //! @return NOT_INITIALIZED if it's not initialized
  Component::ReturnValue Start();
  //! Gets the communication status
  CommunicationStatus GetCommunicationStatus();
  //! Gets the communication status like a string
  std::string GetCommunicationStatusString();
  //! Puts CAN communication in Operational state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue StartCANCommunication();
  //! Resets the communication control state machine
  //! @return OK
  //! @return ERROR
  Component::ReturnValue ResetCANCommunication();
  //! Stops the communication control state machine to STOPPED state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue StopCANCommunication();
  //! Resets the CAN node and its configuration
  //! @return OK
  //! @return ERROR
  Component::ReturnValue ResetNode();
  //! Change the communication control state machine to PRE-OPERATIONAL state
  //! @return OK
  //! @return ERROR
  Component::ReturnValue PreoperationalCANCommunication();

  //! Function to get the status of the drive
  //! @return the status of the motor drive
  DriveState GetDriveState();
  //! Function to get the status of the drive
  //! @return the status of the motor drive
  std::string GetDriveStateString();
  std::string GetDriveStateString(DriveState status);
  //!  Returns the string value of the selected status word
  std::string GetDriveStatusWordIndicatorString(DriveStatusFlags flag);
  //!  Returns the string value of all active status word
  std::vector<std::string> GetFullDriveStatusWordIndicatorString();
  //! Gets drive's mode of operation
  int GetModeOfOperation();
  //! Returns the value of the internal status word as a string
  std::string GetDriveStatusWordString();
  //! Returns the value of the internal status word as a string
  std::string GetDriveStatusRegisterFlagsString();
  //!  Returns the string value of all active drive status flags
  std::vector<std::string> GetFullDriveStatusRegisterString();
  //! Returns the value of the internal status word as an array
  bool* GetDriveStatusRegister();
  //! Returns the value of the internal DS_USER_QUICKSTOP flag as a bool
  bool GetIsUserQuickstop();
  ////! Returns the value of the internal DS_USER_DISABLE flag as a bool
  bool GetIsUserDisable();
  //! Sets the desired status of the driver
  void SetDesiredState(DriveState new_state);
  //! Sets the desired status of the driver set by the user
  void SetUserDesiredState(DriveState new_state);

  //! Function to get the value of all digital inputs
  //! @return drive's digital inputs as an unsigned integer
  //! @return ERROR
  std::vector<bool> GetDigitalInputs();
  //! function for getting the selected digital input value
  //! @return true
  //! @return false
  bool GetDigitalInput(unsigned int input);
  //! Function to get the selected analog input value
  double GetAnalogInput(unsigned int input);
  std::vector<float> GetAnalogInputs();
  //! Function to get the selected value
  double GetVelocityKp();
  //! Function to get the selected value
  double GetVelocityKi();
  //! Function to get the selected value
  double GetVelocityKd();

  //! Function to set drive's digital outputs
  //! @param index as int, number of the digital output
  //! @param value as bool, value of the digital output
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue SetDigitalOutputs(unsigned int index, bool value);
  //! Function to get the values of the digital outputs
  //! @return drive's digital outputs
  std::vector<bool> GetDigitalOutputs();
  //! Function for getting the selected digital output value
  //! @return true
  //! @return false
  bool GetDigitalOutput(unsigned int output);
  //! Function to send SYNC message by the CAN network
  Component::ReturnValue Syncronize();
  //! Gets the value of internal drive status object
  int16_t GetDriveStatus(int object);
  //! Prints / Logs the value of every Drive Status flag
  void PrintDriveStatusRegister();
  //!	Returns the string value of the selected flag
  std::string GetDriveStatusRegisterString(DriveStatusFlags flag);
  //! Gets the CAN ID
  byte GetCanId();
  //! Gets the consumed current
  double GetCurrent();
  //! Gets the average of battery level
  double GetBattery();
  //! Gets the voltage in the power bus
  double GetDCBusVoltage();
  //! Sets peak current limit
  ReturnValue SetPeakCurrentLimit(float current);
  //! Sets continuous current limit
  ReturnValue SetContinuousCurrentLimit(float current);

  //! Checks if MotorDrive needs to be homed, depending on the joint type. If joint must not be homed, IsHomingNeeded
  //! will always return false
  virtual bool IsHomingRequired();
  virtual bool IsHomingRequiredAtStartUp();
  //! Returns true if the driver is homing
  bool IsHoming();
  //! Checks if MotorDrive must be homed because it has lost its homing position
  virtual bool IsHomingNeeded();
  bool HasLostAbsolutePositionValid();
  bool getAbsoluteValidPositionValid();
  bool HasReadAllStatusRegister();
  bool HasHitPositionLimit();
  virtual bool IsBetweenPositionLimits();
  //! Returns if input command is valid
  virtual bool IsCommandValid(const double command);
  Component::ReturnValue ConfigureVelocityPID(ControlParams* velocity_params);
  Component::ReturnValue ConfigureCurrentPID(ControlParams* current_params);
  Component::ReturnValue ConfigureMotorCurrent(ControlParams* current_params);

  //! function to get the motor velocity in revs/s
  virtual double GetMotorVelocity();
  //! function to get the motor position in rads
  virtual double GetMotorPosition();

  // reference, value
  std::tuple<int,float> GetTargetVelocity();
  std::tuple<int,float> GetTargetPosition();
  std::tuple<int,float> GetTargetTorque();
  std::tuple<int,float> GetActualVelocity();
  std::tuple<int,float> GetActualPosition();
  std::tuple<int,float> GetActualTorque();
  //! Gets the current offset applied to the motor
  double GetOffset();
  //! Gets the current offset applied to the motor
  double GetSpin();


  //! function to get the motor position counts
  int GetMotorCounts();
  //! function to set the motor velocity in  rev/s
  virtual Component::ReturnValue SetMotorVelocity(double velocity);
  //! function to set the motor position in rads
  virtual Component::ReturnValue SetMotorPosition(double position);
  //! function to set the motor position in motor counts
  virtual Component::ReturnValue SetMotorPosition(int position);
  //! Triggers the motor homing
  virtual Component::ReturnValue Home();

  //! Gets drive's mode of operation as string
  std::string GetModeOfOperationString();
  virtual std::string ModeOfOperationToString(int mode);

  //! Process received CAN messages
  //! @param msg as a TPCANMsg, the message to process
  void ProcessCANMessage(TPCANMsg msg);

  //! returns an array with all the Watchdogs
  std::vector<Watchdog> getWatchdogArray();

   //! retuns an array with active errors
  virtual std::vector<std::string> GetErrors();

protected:
  //! Function to set the value of the digital outputs
  //! @param Outputs as unsigned int, value of the digital outputs
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue SetDigitalOutputs(unsigned int output);
  virtual int ProcessCANPDOMessage(TPCANMsg msg);
  virtual int ProcessCANSDOMessage(TPCANMsg msg);
  virtual int ProcessCANErrorMessage(TPCANMsg msg);

  //! Sets the pdo ids specific of the manufacturer
  virtual void SetPDOs();

  //! Sends a CAN message
  virtual Component::ReturnValue Send(byte can_id, int type, AccessMode mode, int param = 0, unsigned int subindex = 0);  // byte can_id
  //! Configures devices and performance of the component
  //! @return OK
  //! @return ERROR, if the configuration process fails
  virtual Component::ReturnValue Configure();
  //! Configures CAN TPDOs and RPDOs
  //! @return OK
  //! @return ERROR, if the configuration process fails
  virtual Component::ReturnValue ConfigureCANMsgs();
  //! SDO configuration messages
  virtual Component::ReturnValue ConfigureUserMsgs();
  //! Actions performed on initial state
  virtual void InitState();
  //! Actions performed on ready state
  virtual void ReadyState();
  //! Actions performed on restart state
  virtual void RestartState();
  //! Actions performed on failure state
  virtual void FailureState();

  //! Actions performed on the emergency state
  virtual void EmergencyState();
  //! Actions performed in all states
  virtual void AllState();
  //! Change the value of the communication status
  void SwitchToCommunicationStatus(CommunicationStatus new_status);
  //! Change the value of the communication status
  void SwitchToStatus(DriveState new_status);

  //! Process the value of the digital inputs received from the drive
  virtual int ProcessDigitalInputs(TPCANMsg msg, unsigned int index);
  //! Process the value of the digital Outputs received from the drive
  virtual int ProcessDigitalOutputs(TPCANMsg msg, unsigned int index);
  //! Process the value of the analog inputs received from the drive
  virtual int ProcessAnalogInputs(TPCANMsg msg, unsigned int input_number, unsigned int index);
  //! @param index as unsigned int, initial pose/index of the data msg to start processing the message
  virtual int ProcessModeOfOperation(TPCANMsg msg, unsigned int index);
  //! Process the status_word value received from the drive and changes the status of the object
  //! @param status_word as a byte, with the current drive internal status
  virtual int ProcessStatusWord(TPCANMsg msg, unsigned int index);

  //! Process received CAN SDO message (Default COB-ID= 0x606C).
  //! This type of message contains the following data from Motor Drive:
  //! Velocity Actual Value (4 bytes) Measured post-filter
  //! @param msg as a TPCANMsg, the message to process
  virtual int ProcessActualVelocityValue(TPCANMsg msg, unsigned int index);
  virtual int ProcessTargetVelocityValue(TPCANMsg msg, unsigned int index);
  //! Process received CAN SDO message (Default COB-ID= 0x6064).
  //! This type of message contains the following data from Motor Drive:
  //! Position Ref Value (4 bytes)
  //! @param msg as a TPCANMsg, the message to process
  virtual int ProcessActualPositionValue(TPCANMsg msg, unsigned int index);
  virtual int ProcessTargetPositionValue(TPCANMsg msg, unsigned int index);
  //! Process received CAN SDO message (COB-ID = 0x200F.01)
  //! Contains - DC BUS Voltage (4 bytes) in DV1 units
  //! @param msg as a TPCANMsg, the message to process
  virtual void ProcessDCBusVoltage(TPCANMsg msg, unsigned int index);
  virtual void ProcessTemperature(TPCANMsg msg, unsigned int index);
  //! Process received CAN SDO message (Default COB-ID= 0x2002).
  //! This type of message contains the following data from Motor Drive:
  //! Drive Status Message
  //! @param msg as a TPCANMsg, the message to process
  virtual void ProcessDriveStatus(TPCANMsg msg);

  int ProcessInt16Message(TPCANMsg msg, unsigned int index);
  uint16_t ProcessUInt16Message(TPCANMsg msg, unsigned int index);
  uint32_t ProcessUInt32Message(TPCANMsg msg, unsigned int index);

  int ProcessInt32Message(TPCANMsg msg, unsigned int index);

  //! Actions to control the communication state with the drive
  void ControlCommunicationThread();
  //! Sleeps for a moment
  void Delay();
  void Delay(unsigned int value);
  //! Reset and initialize the status of the drive
  //! @return OK
  //! @return ERROR
  virtual Component::ReturnValue Initialize();
  //! Reads SDO messages from the device
  virtual void ReadSDOMessagesThread();
  //! Specific method to read specific messages
  virtual void ReadSDOMessages();
  //! Configures TPDO messages
  virtual Component::ReturnValue ConfigurePDO(unsigned int communication_object,unsigned int cob_id, byte sync_cycles, bool enable, unsigned int mapping_object, std::vector<PdoMappingStructure> mapping_config);
  //! Configures timer for nodeguard
  virtual Component::ReturnValue ConfigureNodeGuardTimer();
  //! Process the current consumed by the motors
  virtual void ProcessCurrent(TPCANMsg msg, unsigned int index);
  //! Initializes the status register mask
  void InitStatusRegister();
  //! Functions to convert Control Gains to and from driver format
  int32_t velocityKpToDriver(double kp);
  double velocityKpFromDriver(int32_t kp);

  int32_t velocityKiToDriver(double ki);
  double velocityKiFromDriver(int32_t ki);

  int32_t velocityKdToDriver(double kd);
  double velocityKdFromDriver(int32_t kd);
  //! Send the control messages to get the desired state machine
  virtual int DriveStateMachineControl();

  //!
  virtual int ProcessGuardTime(TPCANMsg msg, unsigned int index);
  virtual int ProcessLifeTimeFactor(TPCANMsg msg, unsigned int index);
  virtual int ProcessSoftwareVersion(TPCANMsg msg, unsigned int index);

  virtual int sendControlWord(unsigned int event);

  //! checks the watchdogs of all the pdos defined
  // Returns 0 if OK, -1 if error + an array with the pdos not being received
  int checkWatchdog(std::string id, std::vector<std::string> &watchdogs_not_received);
  //! return 0 if OK, -1 if its repeated
  int addWatchdog(std::string id, double timeout);


  virtual std::string ErrorCodeToString(int code);
  //! return 0 if OK, -1 if its repeated
  int addActiveError(int id, std::string description);

  //! Calculates the home offset in control position + potentiometer
  virtual void CalculateHomeOffset();
  //! Tries to improve the motor consumption when the motor is idle but applying torque (just for Velocity mode)
  virtual void ControlMotorConsumption();

};
}  // namespace robotnik_base_hw_lib

#endif  // _ROBOTNIK_BASE_HW_MOTOR_DRIVE_H_
