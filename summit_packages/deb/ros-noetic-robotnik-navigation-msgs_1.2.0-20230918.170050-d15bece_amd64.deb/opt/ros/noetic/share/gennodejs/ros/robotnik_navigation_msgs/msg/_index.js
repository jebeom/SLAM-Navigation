
"use strict";

let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let DockAction = require('./DockAction.js');
let DockFeedback = require('./DockFeedback.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let BarcodeDockAction = require('./BarcodeDockAction.js');
let BarcodeDockActionResult = require('./BarcodeDockActionResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let MoveFeedback = require('./MoveFeedback.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');
let DockResult = require('./DockResult.js');
let MoveAction = require('./MoveAction.js');
let BarcodeDockActionGoal = require('./BarcodeDockActionGoal.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let MoveGoal = require('./MoveGoal.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let BarcodeDockActionFeedback = require('./BarcodeDockActionFeedback.js');
let BarcodeDockGoal = require('./BarcodeDockGoal.js');
let BarcodeDockFeedback = require('./BarcodeDockFeedback.js');
let MoveActionResult = require('./MoveActionResult.js');
let BarcodeDockResult = require('./BarcodeDockResult.js');
let DockActionResult = require('./DockActionResult.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');
let DockGoal = require('./DockGoal.js');
let MoveResult = require('./MoveResult.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');
let DockActionFeedback = require('./DockActionFeedback.js');

module.exports = {
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  PoseStampedArray: PoseStampedArray,
  DockAction: DockAction,
  DockFeedback: DockFeedback,
  MoveActionGoal: MoveActionGoal,
  BarcodeDockAction: BarcodeDockAction,
  BarcodeDockActionResult: BarcodeDockActionResult,
  DockActionGoal: DockActionGoal,
  MoveFeedback: MoveFeedback,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
  DockResult: DockResult,
  MoveAction: MoveAction,
  BarcodeDockActionGoal: BarcodeDockActionGoal,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  MoveGoal: MoveGoal,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  BarcodeDockActionFeedback: BarcodeDockActionFeedback,
  BarcodeDockGoal: BarcodeDockGoal,
  BarcodeDockFeedback: BarcodeDockFeedback,
  MoveActionResult: MoveActionResult,
  BarcodeDockResult: BarcodeDockResult,
  DockActionResult: DockActionResult,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
  DockGoal: DockGoal,
  MoveResult: MoveResult,
  MoveActionFeedback: MoveActionFeedback,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
  DockActionFeedback: DockActionFeedback,
};
