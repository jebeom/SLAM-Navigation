
"use strict";

let SignalStatus = require('./SignalStatus.js');
let SignalStatusArray = require('./SignalStatusArray.js');

module.exports = {
  SignalStatus: SignalStatus,
  SignalStatusArray: SignalStatusArray,
};
