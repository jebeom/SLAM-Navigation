#ifndef _ROBOT_LOCAL_CONTROL_ROBOT_STATUS_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_ROBOT_STATUS_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control_msgs/RobotStatus.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class RobotStatusComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  RobotStatusComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "RobotStatusComponent")
  {
  }

  virtual ~RobotStatusComponentBase()
  {
  }
  static inline std::string getBaseType()
  {
    return std::string("RobotStatusComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual robot_local_control_msgs::RobotStatus getCurrentStatus() = 0;
};

}  // namespace
#endif //_ROBOT_LOCAL_CONTROL_ROBOT_STATUS_COMPONENT_
