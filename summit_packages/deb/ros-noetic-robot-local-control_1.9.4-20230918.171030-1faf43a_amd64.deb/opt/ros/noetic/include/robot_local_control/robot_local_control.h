#ifndef _ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_
#define _ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_

#include <vector>
#include <ros/ros.h>

#include <rcomponent/rcomponent.h>
#include <robot_local_control/robot_local_control_component.h>
#include <procedures/procedure_component.h>
#include <boost/shared_ptr.hpp>

#include <robot_local_control/control/control_base_component.h>
#include <robot_local_control/operation/operation_base_component.h>
#include <robot_local_control/localization/localization_base_component.h>
#include <robot_local_control/robot_status/robot_status_base_component.h>
#include <robot_local_control/signal_manager/signal_manager_base_component.h>
#include <robot_local_control/navigation/navigation_base_component.h>
#include <robot_local_control/process_manager/process_manager_base_component.h>

#include <procedures_msgs/ProcedureQuery.h>
// Coupling - components to be accessed from the rlc state machine
#include <robot_local_control_msgs/Status.h>
#include <robot_local_control_msgs/LocalizationStatus.h>
#include <robot_local_control_msgs/MissionStatus.h>
#include <robot_local_control_msgs/Missions.h>
#include <robot_local_control_msgs/RobotStatus.h>
#include <robot_local_control_msgs/GoToPetition.h>
#include <robot_local_control_msgs/SimpleGoToWithValidation.h>
#include <robot_local_control_msgs/Cancel.h>
#include <robot_local_control_msgs/MissionCommand.h>
#include <robot_local_control_msgs/MissionParamInt.h>
#include <robot_local_control_msgs/MissionParamFloat.h>
#include <robot_local_control_msgs/MissionParamBool.h>
#include <robot_local_control_msgs/MissionParamString.h>

#include <robotnik_msgs/RobotnikMotorsStatus.h>
#include <robotnik_msgs/inputs_outputs.h>
#include <robotnik_msgs/MotorStatus.h>

#include <std_srvs/Trigger.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Bool.h>

#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <tf/transform_listener.h>

// #define DEFAULT_CONTROL_STATE robot_local_control_msgs::State::CONTROL_STATE_AUTO

// Class for the local control of a robot
class RobotLocalControl : public robot_local_control::RobotLocalControlComponent
{
public:
  RobotLocalControl(ros::NodeHandle n);
  ~RobotLocalControl();

public:
  virtual bool startComponents();

  virtual bool stopComponents();

  /* Rcomponent stuff */
  virtual void initState();
  virtual void standbyState();
  virtual void readyState();
  virtual void allState();
  virtual int rosSetup();
  virtual void rosReadParams();
  virtual int setup();
  virtual int stop();
  virtual std::string getStateString();

protected:
  /* Rcomponent stuff !*/

  // performs the global state machine control (INIT, STANDBY, READY, EMERGENCY, FAILURE)
  void globalStateMachine();

  //  performs the robot status machine control
  void robotStatusMachine();

private:
  boost::shared_ptr<robot_local_control::ControlComponentBase> control_component;
  boost::shared_ptr<robot_local_control::LocalizationComponentBase> localization_component;
  boost::shared_ptr<robot_local_control::NavigationComponentBase> navigation_component;
  boost::shared_ptr<robot_local_control::OperationComponentBase> operation_component;
  boost::shared_ptr<robot_local_control::RobotStatusComponentBase> robot_status_component;
  boost::shared_ptr<robot_local_control::SignalManagerComponentBase> signal_manager_component;
  boost::shared_ptr<robot_local_control::ProcessManagerComponentBase> process_manager_component;
  std::vector<boost::shared_ptr<robot_local_control::RobotLocalControlComponent> > components_;

  std::vector<procedures::GenericProcedureComponent::Ptr> procedure_components_;

  bool methodComponentCallbackManager(
      const ros::ServiceEvent<service_shifter::ServiceShifter, service_shifter::ServiceShifter>& event,
      boost::function<bool(const service_shifter::ServiceShifter&, service_shifter::ServiceShifter&)> recallback);

  // Method to process a command and return the value after processing
  bool processMissionCommand(robot_local_control_msgs::MissionCommand msg, std::string* message);

  /* ROS  */

  // Publishers
  ros::Publisher state_pub_;

  // transform listener
  tf::TransformListener tf_listener_;

  /* ROS !*/

  bool loadComponent(const std::string& name, const std::string& type,
                     robot_local_control::RobotLocalControlComponent::Ptr& component);

  pluginlib::ClassLoader<robot_local_control::RobotLocalControlComponent>* components_loader_;

  /* Robot state */
  // Robot State Machine
  std::string robot_id_;
  std::string robot_control_state_;
  std::string operation_state_;
  // Robot Mission
  robot_local_control_msgs::Missions mission_status_;
  robot_local_control_msgs::Missions last_mission_status_;
  // missions needs to know which procedure is being called to control the end of the mission!
  robot_local_control_msgs::LocalizationStatus localization_status_;
  robot_local_control_msgs::LocalizationStatus last_localization_status_;
  // Robot Status
  robot_local_control_msgs::RobotStatus robot_status_;
  // Navigation needs to know which procedure is being used to set the state
  /* Robot state !*/

  // Frames
  std::string global_frame_;
  std::string base_frame_;
  std::string odom_frame_;
};
#endif  //_ROBOT_LOCAL_CONTROL_ROBOT_LOCAL_CONTROL_
