#ifndef _ROBOT_LOCAL_CONTROL_NAVIGATION_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_NAVIGATION_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <pluginlib/class_loader.h>

#include <procedures/procedure_component.h>

#include <robot_local_control/robot_local_control_component.h>

#include <robot_local_control_msgs/NavigationStatus.h>

namespace robot_local_control
{
class NavigationComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  NavigationComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "NavigationComponent")
  {
  }

  virtual ~NavigationComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("NavigationComponent");
  }

  virtual std::string getType()
  {
    return getBaseType();
  }

  virtual void cancelAllProcedures() = 0;

  // this one adds a procedure component...
  virtual bool setProcedureComponent(procedures::GenericProcedureComponent::Ptr component) = 0;

  virtual robot_local_control_msgs::NavigationStatus getCurrentStatus() = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_NAVIGATION_COMPONENT_BASE_
