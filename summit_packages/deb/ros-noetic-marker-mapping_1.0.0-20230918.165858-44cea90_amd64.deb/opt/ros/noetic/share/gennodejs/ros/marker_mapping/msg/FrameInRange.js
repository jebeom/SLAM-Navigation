// Auto-generated. Do not edit!

// (in-package marker_mapping.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FrameInRange {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frame_id = null;
      this.is_being_used = null;
    }
    else {
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('is_being_used')) {
        this.is_being_used = initObj.is_being_used
      }
      else {
        this.is_being_used = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrameInRange
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [is_being_used]
    bufferOffset = _serializer.bool(obj.is_being_used, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrameInRange
    let len;
    let data = new FrameInRange(null);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [is_being_used]
    data.is_being_used = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.frame_id);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'marker_mapping/FrameInRange';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '127192f91e4d17ec92c28ed46799e2d1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string frame_id
    bool is_being_used
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrameInRange(null);
    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.is_being_used !== undefined) {
      resolved.is_being_used = msg.is_being_used;
    }
    else {
      resolved.is_being_used = false
    }

    return resolved;
    }
};

module.exports = FrameInRange;
