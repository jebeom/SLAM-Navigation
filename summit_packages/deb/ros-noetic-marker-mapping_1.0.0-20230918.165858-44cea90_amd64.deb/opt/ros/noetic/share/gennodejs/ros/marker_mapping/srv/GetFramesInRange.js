// Auto-generated. Do not edit!

// (in-package marker_mapping.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let FrameInRange = require('../msg/FrameInRange.js');

//-----------------------------------------------------------

class GetFramesInRangeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetFramesInRangeRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetFramesInRangeRequest
    let len;
    let data = new GetFramesInRangeRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'marker_mapping/GetFramesInRangeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetFramesInRangeRequest(null);
    return resolved;
    }
};

class GetFramesInRangeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frames_in_range = null;
    }
    else {
      if (initObj.hasOwnProperty('frames_in_range')) {
        this.frames_in_range = initObj.frames_in_range
      }
      else {
        this.frames_in_range = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetFramesInRangeResponse
    // Serialize message field [frames_in_range]
    // Serialize the length for message field [frames_in_range]
    bufferOffset = _serializer.uint32(obj.frames_in_range.length, buffer, bufferOffset);
    obj.frames_in_range.forEach((val) => {
      bufferOffset = FrameInRange.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetFramesInRangeResponse
    let len;
    let data = new GetFramesInRangeResponse(null);
    // Deserialize message field [frames_in_range]
    // Deserialize array length for message field [frames_in_range]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.frames_in_range = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.frames_in_range[i] = FrameInRange.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.frames_in_range.forEach((val) => {
      length += FrameInRange.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'marker_mapping/GetFramesInRangeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0358f4ef3cf17e085e167d3eb1f7ee2e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    FrameInRange[] frames_in_range
    
    ================================================================================
    MSG: marker_mapping/FrameInRange
    string frame_id
    bool is_being_used
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetFramesInRangeResponse(null);
    if (msg.frames_in_range !== undefined) {
      resolved.frames_in_range = new Array(msg.frames_in_range.length);
      for (let i = 0; i < resolved.frames_in_range.length; ++i) {
        resolved.frames_in_range[i] = FrameInRange.Resolve(msg.frames_in_range[i]);
      }
    }
    else {
      resolved.frames_in_range = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetFramesInRangeRequest,
  Response: GetFramesInRangeResponse,
  md5sum() { return '0358f4ef3cf17e085e167d3eb1f7ee2e'; },
  datatype() { return 'marker_mapping/GetFramesInRange'; }
};
