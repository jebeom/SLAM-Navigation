
"use strict";

let SetFrameId = require('./SetFrameId.js')
let InitPoseFromFrame = require('./InitPoseFromFrame.js')
let GetFramesInRange = require('./GetFramesInRange.js')
let InitPoseFromMarker = require('./InitPoseFromMarker.js')
let SaveMarker = require('./SaveMarker.js')
let SaveFrame = require('./SaveFrame.js')

module.exports = {
  SetFrameId: SetFrameId,
  InitPoseFromFrame: InitPoseFromFrame,
  GetFramesInRange: GetFramesInRange,
  InitPoseFromMarker: InitPoseFromMarker,
  SaveMarker: SaveMarker,
  SaveFrame: SaveFrame,
};
