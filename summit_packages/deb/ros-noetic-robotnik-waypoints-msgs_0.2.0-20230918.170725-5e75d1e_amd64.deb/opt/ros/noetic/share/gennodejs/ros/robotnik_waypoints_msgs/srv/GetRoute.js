// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let Route = require('../msg/Route.js');

//-----------------------------------------------------------

class GetRouteRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id_route = null;
    }
    else {
      if (initObj.hasOwnProperty('id_route')) {
        this.id_route = initObj.id_route
      }
      else {
        this.id_route = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRouteRequest
    // Serialize message field [id_route]
    bufferOffset = _serializer.int16(obj.id_route, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRouteRequest
    let len;
    let data = new GetRouteRequest(null);
    // Deserialize message field [id_route]
    data.id_route = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetRouteRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b33d751d5a263223493a9dd91a487589';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 id_route
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRouteRequest(null);
    if (msg.id_route !== undefined) {
      resolved.id_route = msg.id_route;
    }
    else {
      resolved.id_route = 0
    }

    return resolved;
    }
};

class GetRouteResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.route = null;
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('route')) {
        this.route = initObj.route
      }
      else {
        this.route = new Route();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRouteResponse
    // Serialize message field [route]
    bufferOffset = Route.serialize(obj.route, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRouteResponse
    let len;
    let data = new GetRouteResponse(null);
    // Deserialize message field [route]
    data.route = Route.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Route.getMessageSize(object.route);
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetRouteResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3d19ba180eab95211e3e130b40ccef6a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    robotnik_waypoints_msgs/Route route
    bool success
    string message
    
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Route
    string GOAL_TARGET_TYPE_CARTESIAN = CARTESIAN
    string GOAL_TARGET_TYPE_GPS = GPS
    
    int16 id
    string name
    string description
    
    string goal_target_type
    robotnik_waypoints_msgs/Point[] points
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Point
    
    int64 id
    int64 fk_id_route
    int64 position_index
    
    string name
    string description
    
    float64 x
    float64 y
    float64 z
    
    string frame
    
    string local_planner
    
    
    float32 orientation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRouteResponse(null);
    if (msg.route !== undefined) {
      resolved.route = Route.Resolve(msg.route)
    }
    else {
      resolved.route = new Route()
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetRouteRequest,
  Response: GetRouteResponse,
  md5sum() { return 'a23eb13be52c21d237a266f628eb37c3'; },
  datatype() { return 'robotnik_waypoints_msgs/GetRoute'; }
};
