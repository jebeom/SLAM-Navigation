// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Route = require('../msg/Route.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class RouteActionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.route = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('route')) {
        this.route = initObj.route
      }
      else {
        this.route = new Route();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RouteActionRequest
    // Serialize message field [id]
    bufferOffset = _serializer.int16(obj.id, buffer, bufferOffset);
    // Serialize message field [route]
    bufferOffset = Route.serialize(obj.route, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RouteActionRequest
    let len;
    let data = new RouteActionRequest(null);
    // Deserialize message field [id]
    data.id = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [route]
    data.route = Route.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Route.getMessageSize(object.route);
    return length + 2;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/RouteActionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c81ad16fdfcfe468fc7bb34d97e55ec3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 id
    robotnik_waypoints_msgs/Route route
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Route
    string GOAL_TARGET_TYPE_CARTESIAN = CARTESIAN
    string GOAL_TARGET_TYPE_GPS = GPS
    
    int16 id
    string name
    string description
    
    string goal_target_type
    robotnik_waypoints_msgs/Point[] points
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Point
    
    int64 id
    int64 fk_id_route
    int64 position_index
    
    string name
    string description
    
    float64 x
    float64 y
    float64 z
    
    string frame
    
    string local_planner
    
    
    float32 orientation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RouteActionRequest(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.route !== undefined) {
      resolved.route = Route.Resolve(msg.route)
    }
    else {
      resolved.route = new Route()
    }

    return resolved;
    }
};

class RouteActionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RouteActionResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RouteActionResponse
    let len;
    let data = new RouteActionResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/RouteActionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RouteActionResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: RouteActionRequest,
  Response: RouteActionResponse,
  md5sum() { return 'ac8bcfe40cba86bff9b5c506f43d8297'; },
  datatype() { return 'robotnik_waypoints_msgs/RouteAction'; }
};
