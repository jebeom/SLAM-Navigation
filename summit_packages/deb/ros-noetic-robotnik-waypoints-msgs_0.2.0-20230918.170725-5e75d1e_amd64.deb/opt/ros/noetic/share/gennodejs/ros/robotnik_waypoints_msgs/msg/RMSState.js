// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RMSState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.current_state_description = null;
      this.current_state = null;
      this.last_state = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('current_state_description')) {
        this.current_state_description = initObj.current_state_description
      }
      else {
        this.current_state_description = '';
      }
      if (initObj.hasOwnProperty('current_state')) {
        this.current_state = initObj.current_state
      }
      else {
        this.current_state = '';
      }
      if (initObj.hasOwnProperty('last_state')) {
        this.last_state = initObj.last_state
      }
      else {
        this.last_state = '';
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RMSState
    // Serialize message field [current_state_description]
    bufferOffset = _serializer.string(obj.current_state_description, buffer, bufferOffset);
    // Serialize message field [current_state]
    bufferOffset = _serializer.string(obj.current_state, buffer, bufferOffset);
    // Serialize message field [last_state]
    bufferOffset = _serializer.string(obj.last_state, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RMSState
    let len;
    let data = new RMSState(null);
    // Deserialize message field [current_state_description]
    data.current_state_description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [current_state]
    data.current_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [last_state]
    data.last_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.current_state_description);
    length += _getByteLength(object.current_state);
    length += _getByteLength(object.last_state);
    length += _getByteLength(object.message);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'robotnik_waypoints_msgs/RMSState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '01708df8f56f1d258980f038be76da52';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string STATE_UNKNOWN=UNKNOWN
    string STATE_INIT=INIT
    string STATE_IDLE=IDLE
    string STATE_WAITING_CONFIRMATION=WAITING CONFIRMATION
    string STATE_SEND_PLAN=SEND PLAN
    string STATE_NAVIGATING=NAVIGATING
    string STATE_FINISH=FINISH
    string STATE_CANCEL=CANCEL
    string STATE_ERROR=ERROR
    
    string current_state_description
    string current_state
    string last_state
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RMSState(null);
    if (msg.current_state_description !== undefined) {
      resolved.current_state_description = msg.current_state_description;
    }
    else {
      resolved.current_state_description = ''
    }

    if (msg.current_state !== undefined) {
      resolved.current_state = msg.current_state;
    }
    else {
      resolved.current_state = ''
    }

    if (msg.last_state !== undefined) {
      resolved.last_state = msg.last_state;
    }
    else {
      resolved.last_state = ''
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

// Constants for message
RMSState.Constants = {
  STATE_UNKNOWN: 'UNKNOWN',
  STATE_INIT: 'INIT',
  STATE_IDLE: 'IDLE',
  STATE_WAITING_CONFIRMATION: 'WAITING CONFIRMATION',
  STATE_SEND_PLAN: 'SEND PLAN',
  STATE_NAVIGATING: 'NAVIGATING',
  STATE_FINISH: 'FINISH',
  STATE_CANCEL: 'CANCEL',
  STATE_ERROR: 'ERROR',
}

module.exports = RMSState;
