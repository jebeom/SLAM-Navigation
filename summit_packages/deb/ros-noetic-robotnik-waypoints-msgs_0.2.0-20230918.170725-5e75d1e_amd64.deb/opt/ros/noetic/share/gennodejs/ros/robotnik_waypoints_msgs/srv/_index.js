
"use strict";

let GetRoute = require('./GetRoute.js')
let GoalIdRoute = require('./GoalIdRoute.js')
let RouteAction = require('./RouteAction.js')
let GetRoutes = require('./GetRoutes.js')
let GetPoints = require('./GetPoints.js')
let PointAction = require('./PointAction.js')

module.exports = {
  GetRoute: GetRoute,
  GoalIdRoute: GoalIdRoute,
  RouteAction: RouteAction,
  GetRoutes: GetRoutes,
  GetPoints: GetPoints,
  PointAction: PointAction,
};
