// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let Point = require('../msg/Point.js');

//-----------------------------------------------------------

class GetPointsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id_route = null;
    }
    else {
      if (initObj.hasOwnProperty('id_route')) {
        this.id_route = initObj.id_route
      }
      else {
        this.id_route = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPointsRequest
    // Serialize message field [id_route]
    bufferOffset = _serializer.int16(obj.id_route, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPointsRequest
    let len;
    let data = new GetPointsRequest(null);
    // Deserialize message field [id_route]
    data.id_route = _deserializer.int16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetPointsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b33d751d5a263223493a9dd91a487589';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int16 id_route
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPointsRequest(null);
    if (msg.id_route !== undefined) {
      resolved.id_route = msg.id_route;
    }
    else {
      resolved.id_route = 0
    }

    return resolved;
    }
};

class GetPointsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.points = null;
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPointsResponse
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPointsResponse
    let len;
    let data = new GetPointsResponse(null);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.points.forEach((val) => {
      length += Point.getMessageSize(val);
    });
    length += _getByteLength(object.message);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GetPointsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7f1a7e022b8ad7ddf9c1bcbcc1f4b965';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    robotnik_waypoints_msgs/Point[] points
    bool success
    string message
    
    
    ================================================================================
    MSG: robotnik_waypoints_msgs/Point
    
    int64 id
    int64 fk_id_route
    int64 position_index
    
    string name
    string description
    
    float64 x
    float64 y
    float64 z
    
    string frame
    
    string local_planner
    
    
    float32 orientation
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPointsResponse(null);
    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = Point.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetPointsRequest,
  Response: GetPointsResponse,
  md5sum() { return 'fe57ba4fc861d59ee276f0afb3a1ba7d'; },
  datatype() { return 'robotnik_waypoints_msgs/GetPoints'; }
};
