// Auto-generated. Do not edit!

// (in-package robotnik_waypoints_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class GoalIdRouteRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id_route = null;
      this.controller = null;
      this.planner = null;
      this.navigation_type = null;
      this.goal_tolerance = null;
    }
    else {
      if (initObj.hasOwnProperty('id_route')) {
        this.id_route = initObj.id_route
      }
      else {
        this.id_route = 0;
      }
      if (initObj.hasOwnProperty('controller')) {
        this.controller = initObj.controller
      }
      else {
        this.controller = [];
      }
      if (initObj.hasOwnProperty('planner')) {
        this.planner = initObj.planner
      }
      else {
        this.planner = [];
      }
      if (initObj.hasOwnProperty('navigation_type')) {
        this.navigation_type = initObj.navigation_type
      }
      else {
        this.navigation_type = '';
      }
      if (initObj.hasOwnProperty('goal_tolerance')) {
        this.goal_tolerance = initObj.goal_tolerance
      }
      else {
        this.goal_tolerance = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GoalIdRouteRequest
    // Serialize message field [id_route]
    bufferOffset = _serializer.int64(obj.id_route, buffer, bufferOffset);
    // Serialize message field [controller]
    bufferOffset = _arraySerializer.string(obj.controller, buffer, bufferOffset, null);
    // Serialize message field [planner]
    bufferOffset = _arraySerializer.string(obj.planner, buffer, bufferOffset, null);
    // Serialize message field [navigation_type]
    bufferOffset = _serializer.string(obj.navigation_type, buffer, bufferOffset);
    // Serialize message field [goal_tolerance]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.goal_tolerance, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GoalIdRouteRequest
    let len;
    let data = new GoalIdRouteRequest(null);
    // Deserialize message field [id_route]
    data.id_route = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [controller]
    data.controller = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [planner]
    data.planner = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [navigation_type]
    data.navigation_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [goal_tolerance]
    data.goal_tolerance = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.controller.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.planner.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.navigation_type);
    return length + 76;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GoalIdRouteRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2021ba79699d2a1d877f1112f33dc69a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 id_route
    string[] controller
    string[] planner
    string navigation_type
    geometry_msgs/Pose goal_tolerance
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GoalIdRouteRequest(null);
    if (msg.id_route !== undefined) {
      resolved.id_route = msg.id_route;
    }
    else {
      resolved.id_route = 0
    }

    if (msg.controller !== undefined) {
      resolved.controller = msg.controller;
    }
    else {
      resolved.controller = []
    }

    if (msg.planner !== undefined) {
      resolved.planner = msg.planner;
    }
    else {
      resolved.planner = []
    }

    if (msg.navigation_type !== undefined) {
      resolved.navigation_type = msg.navigation_type;
    }
    else {
      resolved.navigation_type = ''
    }

    if (msg.goal_tolerance !== undefined) {
      resolved.goal_tolerance = geometry_msgs.msg.Pose.Resolve(msg.goal_tolerance)
    }
    else {
      resolved.goal_tolerance = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

class GoalIdRouteResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GoalIdRouteResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GoalIdRouteResponse
    let len;
    let data = new GoalIdRouteResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'robotnik_waypoints_msgs/GoalIdRouteResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '937c9679a518e3a18d831e57125ea522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GoalIdRouteResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GoalIdRouteRequest,
  Response: GoalIdRouteResponse,
  md5sum() { return '3974bcd56563bac293820c2e060e66ec'; },
  datatype() { return 'robotnik_waypoints_msgs/GoalIdRoute'; }
};
