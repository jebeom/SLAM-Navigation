
"use strict";

let Record = require('./Record.js')

module.exports = {
  Record: Record,
};
