#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from rcomponent.rcomponent import *

# Insert here general imports:
import math

# Insert here msg and srv imports:
import rospy
from robotnik_msgs.msg import BatteryStatus
from std_msgs.msg import String
from std_msgs.msg import Float32
import pandas as pandas
import time 
from datetime import datetime 
import csv
import pathlib
import os
import glob
from average import average

class BattInformation(RComponent):
    """
    
    """

    def __init__(self):
        self.voltage = 0
        self.current = 0
        self.level= 0
        self.is_charging = False
        self.capacity = 0
        self.noisy_capacity = 0
        self.time_remaining = 0
        self.time_charging = 0
        self.max_size_file = 0
        self.sizefile = 0
        self.path =""
        
        #self.timer = 0
        self.save_time_param = 0
        self.get_average_voltage=0
        
        RComponent.__init__(self)

    def ros_read_params(self):
        """Gets params from param server"""
        RComponent.ros_read_params(self)

        self.max_size_file_param = rospy.get_param('~max_size',10)
        self.path = rospy.get_param('~destination_folder',str(pathlib.Path(__file__).parent.absolute()))
        #self.timer_param = rospy.get_param('~save_time',10)
        self.save_time_param = rospy.get_param('~media_timer_param',5)
        self.get_value_time_param = rospy.get_param('~get_value_timer',1)

    def ros_setup(self):
        """Creates and inits ROS components"""

        RComponent.ros_setup(self)

        self.battery_info_sub=rospy.Subscriber('/robot/battery_estimator/data',BatteryStatus,self.battery_info_cb)
        RComponent.add_topics_health(self, self.battery_info_sub, topic_id='battery_info_sub', timeout=1.0, required=True)

        self.battery_capacity_sub =rospy.Subscriber('/robot/battery_estimator/debug/present_capacity',Float32,self.capacity_cb)
        RComponent.add_topics_health(self, self.battery_capacity_sub, topic_id='battery_capacity_sub', timeout=1.0, required=False)

        self.battery_noisy_capacity_sub= rospy.Subscriber('/robot/battery_estimator/debug/noisy_present_capacity',Float32,self.noisy_capacity_cb)
        RComponent.add_topics_health(self, self.battery_noisy_capacity_sub, topic_id='battery_noisy_capacity_sub', timeout=1.0, required=False)

        save_time = rospy.Timer(rospy.Duration(self.save_time_param), self.get_average_cb)

        get_value_timer = rospy.Timer(rospy.Duration(self.get_value_time_param),self.add_value_cb)

        return 0

    def init_state(self):
        self.max_size_file=self.bytes_to_mb(self.max_size_file_param)
        #self.timer = self.timer_param
        self.folder = self.path + '/' + time.strftime("%d-%m-%Y_%H-%M-%S")+'.csv'
        self.fieldnames = ['date', 'voltage', 'current', 'level', 'is_charging','capacity','noisy_capacity','time_remaining','time_charging'] 
        self.average_voltage=average(self.save_time_param)
        self.average_current=average(self.save_time_param)
        self.average_capacity=average(self.save_time_param)
        self.average_noisy_capacity=average(self.save_time_param)
        return RComponent.init_state(self)

    def ready_state(self):
        """Actions performed in ready state"""
        #print(self.max_size_file)
        if(self.check_topics_health() == False):
            self.switch_to_state(State.EMERGENCY_STATE)
            return RComponent.ready_state(self)
        self.folder=self.sort_file()
        
        
        return RComponent.ready_state(self)

    def emergency_state(self):
        if(self.check_topics_health() == True):
            self.switch_to_state(State.READY_STATE)

    def shutdown(self):
        """Shutdowns device

        Return:
            0 : if it's performed successfully
            -1: if there's any problem or the component is running
        """

        return RComponent.shutdown(self)

    def switch_to_state(self, new_state):
        """Performs the change of state"""

        return RComponent.switch_to_state(self, new_state)

    def battery_info_cb(self, msg):

        self.voltage = msg.voltage
        self.current = msg.current
        self.level = msg.level
        self.is_charging = msg.is_charging
        self.time_remaining=  msg.time_remaining
        self.time_charging=msg.time_charging
        self.tick_topics_health('battery_info_sub')

    def capacity_cb(self,msg):
        self.capacity = msg.data
        self.tick_topics_health('battery_capacity_sub')
        

    def noisy_capacity_cb(self,msg):
        self.noisy_capacity = msg.data
        self.tick_topics_health('battery_noisy_capacity_sub')
        
    
    def size_file_function(self,file):

        self.sizefile = os.stat(str(file)).st_size
        #print ('size:' + str(self.sizefile))
        return self.sizefile

    def create_file(self,file):
        csv_file= open(file,'w')
        writer = csv.DictWriter(csv_file, fieldnames=self.fieldnames)        
        writer.writeheader()

    def write_file(self,file):
        csv_file= open(file,'a')
        writer=csv.DictWriter(csv_file,fieldnames=self.fieldnames)
        writer.writerow({'date': datetime.now().ctime(),
        'voltage':self.get_average_voltage,
        'current':self.get_average_current,
        'level':self.level,
        'is_charging':self.is_charging,
        'capacity':self.get_average_capacity,
        'noisy_capacity':self.get_average_noisy_capacity,
        'time_remaining':self.time_remaining,
        'time_charging':self.time_charging})
        #self.timer=self.timer -1
        csv_file.close()

        #if self.timer==0:
        #   csv_file.close()
        #   self.timer=self.timer_param 

    def sort_file(self):
        path= r''+str(self.path)# + '/'# + time.strftime("%d-%m-%Y_%H-%M-%S") 
        archives =glob.glob(path+os.path.sep+'*.csv')
        archives.sort(key=os.path.getctime)
     
        if len(archives) >= 1:
            return archives[-1]
        else:
            self.create_file(str(self.folder)) 
            return str(self.folder)

    def bytes_to_mb(self,mb):
        transform = mb*1048576
        return transform

    def get_average_cb(self,event=None):
        self.get_average_voltage = self.average_voltage.get_average()
        self.get_average_current= self.average_current.get_average()
        self.get_average_capacity= self.average_capacity.get_average()
        self.get_average_noisy_capacity= self.average_noisy_capacity.get_average()
        #print( "voltage:",self.get_average_voltage)

        if os.path.isfile(str(self.folder)) and self.sizefile < self.max_size_file:
            self.write_file(str(self.folder))

        else:
            self.folder=self.path + '/' + time.strftime("%d-%m-%Y_%H-%M-%S")+'.csv'
            self.create_file(str(self.folder))  
        self.size_file_function(str(self.folder))

        #print("average:%d"%(get_average_voltage))
    
    def add_value_cb(self,event=None):
        self.average_voltage.add_value(self.voltage)
        self.average_current.add_value(self.current)
        self.average_capacity.add_value(self.capacity)
        self.average_noisy_capacity.add_value(self.noisy_capacity)
