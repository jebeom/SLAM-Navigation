#!/usr/bin/env python

import math
class average:

    def __init__(self,maxcount):
        self.array =[]
        
        self.max_Acount=maxcount
           
    def get_average(self):
        avg=0.0
        if len(self.array)==0:
            return -1.0

        for i in self.array:
            avg=avg+float(i)
        avg=avg/float(len(self.array))
        return avg
        print(avg)

    def add_value(self,value):
        self.array.append(value)
        #print("value:",value)
        #for i in self.array:
        #    print(i)  
        if len(self.array)>self.max_Acount:
            self.array.pop(0)       