#! /usr/bin/env python

import rospy
from robotnik_msgs.msg import BatteryStatus
from std_msgs.msg import Float32 ,UInt32
rospy.init_node('publicador')

pub1=rospy.Publisher('/robot/battery_estimator/data',BatteryStatus,queue_size=1)
pub2=rospy.Publisher('/robot/battery_estimator/debug/present_capacity',Float32,queue_size=1)
pub3=rospy.Publisher('/robot/battery_estimator/debug/noisy_present_capacity',Float32,queue_size=1)
informacion=BatteryStatus()
data=Float32()
data2=Float32()
rate =rospy.Rate(2)
informacion.voltage=1
informacion.current=2
informacion.is_charging=False
informacion.level=3
informacion.time_remaining=4
informacion.time_charging=4
data.data=4
data2.data=5
while not rospy.is_shutdown():
    pub1.publish(informacion)
    pub2.publish(data)
    pub3.publish(data2)
    rate.sleep()
