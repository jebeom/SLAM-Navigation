#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from batt_information import BattInformation


def main():

    rospy.init_node("batt_information_node")

    rc_node = BattInformation()

    rospy.loginfo('%s: starting' % (rospy.get_name()))

    rc_node.start()


if __name__ == "__main__":
    main()
