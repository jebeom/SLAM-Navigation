#!/usr/bin/env python  
import rospy

import tf
import geometry_msgs.msg

from nav_msgs.msg import Odometry

import math

rospy.init_node('robot')
current_x = 0
current_y = 0
current_theta = 0
ts = 0.1
last = rospy.Time.now()
br = tf.TransformBroadcaster()
current_twist = geometry_msgs.msg.Twist()

def handle_cmd_vel(msg):
    global current_x
    global current_y
    global current_theta
    global current_twist

    if rospy.Time.now() - last < rospy.Duration(ts):
        return

    current_x += 2*(math.cos(current_theta)*msg.linear.x*ts - math.sin(current_theta)*msg.linear.y*ts)
    current_y += 2*(math.sin(current_theta)*msg.linear.x*ts + math.cos(current_theta)*msg.linear.y*ts)
    current_theta += 2*msg.angular.z*ts
    current_twist = msg

base_frame_id = rospy.get_param("~base_frame_id", "base_link")
odom_frame_id = rospy.get_param("~odom_frame_id", "odom")
ts = rospy.get_param("~time_step", 0.1)
rospy.Subscriber('cmd_vel', geometry_msgs.msg.Twist, handle_cmd_vel, queue_size=1)

odom = Odometry()
odom.header.frame_id = odom_frame_id
odom.child_frame_id = base_frame_id
pub = rospy.Publisher('odom', Odometry)

rate = rospy.Rate(1/ts)

while not rospy.is_shutdown():
    odom.pose.pose = geometry_msgs.msg.Pose(geometry_msgs.msg.Point(current_x, current_y, 0), geometry_msgs.msg.Quaternion(*tf.transformations.quaternion_from_euler(0, 0, current_theta)))
    odom.twist.twist = current_twist
    pub.publish(odom)
    br.sendTransform((current_x, current_y, 0), tf.transformations.quaternion_from_euler(0, 0, current_theta), rospy.Time.now(), base_frame_id, odom_frame_id)
    rate.sleep()
